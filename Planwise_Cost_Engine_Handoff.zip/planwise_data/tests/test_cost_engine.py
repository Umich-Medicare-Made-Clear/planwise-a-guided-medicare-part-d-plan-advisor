import sys,json,unittest
from pathlib import Path
from decimal import Decimal as D
from copy import deepcopy
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from cost_engine import payment, simulate, compare_plans, scheduled_dates, ROOT, money

def rule(kind='1', amount='10', minimum='0', maximum='0'):
    return dict(type=kind,amount=amount,minimum=minimum,maximum=maximum)
def drug(ndc='A',gross='10',applies=True,r=None):
    return dict(ndc=ndc,medication_name=ndc,gross_per_fill=D(gross),deductible_applies=applies,rule=r or rule())

class Arithmetic(unittest.TestCase):
    def test_calendar(self):
        dates=scheduled_dates();self.assertEqual(len(dates),13)
        self.assertEqual(str(dates[-1]),'2026-12-27')
    def test_longer_schedules(self):
        self.assertEqual(len(scheduled_dates(60)),7)
        self.assertEqual(len(scheduled_dates(90)),5)
        with self.assertRaises(ValueError):scheduled_dates(45)
    def test_mixed_schedule(self):
        a=drug('A');a['days_supply']=30
        b=drug('B');b['days_supply']=90
        x=simulate(dict(premium=0,deductible=615),[a,b])
        self.assertEqual(len(x['fill_ledger']),18)
        self.assertEqual(x['annual_medication_cost'],180)
        self.assertEqual([r['date'] for r in x['fill_ledger']],sorted(r['date'] for r in x['fill_ledger']))
    def test_copay_capped_at_price(self): self.assertEqual(payment(D('3'),rule()),D('3.00'))
    def test_coinsurance_bounds(self):
        self.assertEqual(payment(D('100'),rule('2','.25','30','40')),D('30.00'))
        self.assertEqual(payment(D('200'),rule('2','.25','30','40')),D('40.00'))
    def test_invalid_rates(self):
        for r in [rule('0'),rule('2','25'),rule('2','.2','50','30')]:
            with self.assertRaises(ValueError):payment(D('100'),r)
    def test_missing_not_zero(self):
        with self.assertRaises(ValueError):payment(D('100'),rule(amount=None))
    def test_rounding(self):self.assertEqual(money('1.005'),D('1.01'))
    def test_shared_deductible(self):
        # 26 claims of $10, one shared $15 deductible, then 25% of $245.
        x=simulate(dict(premium=10,deductible=15),[drug('A',r=rule('2','.25')),drug('B',r=rule('2','.25'))])
        self.assertEqual(x['deductible_paid'],D('15'))
        self.assertEqual(x['annual_medication_cost'],D('76.25'))
        self.assertEqual(x['annual_total'],D('196.25'))
    def test_exempt_tier(self):
        x=simulate(dict(premium=0,deductible=615),[drug(applies=False,r=rule(amount='2'))])
        self.assertEqual(x['deductible_paid'],0);self.assertEqual(x['annual_medication_cost'],26)
    def test_boundary_copay(self):
        x=simulate(dict(premium=0,deductible=7),[drug(r=rule(amount='5'))])
        self.assertEqual(x['fill_ledger'][0]['member_payment'],10)
        self.assertEqual(x['annual_medication_cost'],70)
    def test_separate_premiums(self):
        x=simulate(dict(premium=200,deductible=615),[])
        self.assertEqual(x['annual_total'],2400)
    def test_threshold_blocks_unsupported(self):
        with self.assertRaisesRegex(ValueError,'annual_limit_rules_unresolved'):
            simulate(dict(premium=0,deductible=615),[drug(gross='200')])
    def test_monthly_and_ledger_reconcile(self):
        x=simulate(dict(premium=5,deductible=15),[drug()])
        self.assertEqual(sum(r['total'] for r in x['monthly_costs']),x['annual_total'])
        self.assertEqual(sum(r['member_payment'] for r in x['fill_ledger']),x['annual_medication_cost'])

class Connected(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.profile=json.loads((ROOT/'evidence/integrated_intake_example.json').read_text())
    def test_two_drug_profile(self):
        x=compare_plans(self.profile);self.assertEqual(len(x['plans']),12)
        for p in x['plans']:
            self.assertEqual(p['status'],'estimated_under_documented_assumptions')
            self.assertEqual(len(p['fill_ledger']),26)
            self.assertEqual(p['annual_total'],p['annual_premium']+p['annual_medication_cost'])
            self.assertLessEqual(p['deductible_paid'],p['deductible'])
    def test_single_drug(self):
        p=deepcopy(self.profile);p['tier1']['medications']=p['tier1']['medications'][:1]
        self.assertEqual(len(compare_plans(p)['plans']),12)
    def test_no_drugs(self):
        p=deepcopy(self.profile);p['tier1']['medications']=[]
        for row in compare_plans(p)['plans']:self.assertEqual(row['annual_total'],row['premium']*12)
    def test_unsupported_fill_rejected(self):
        p=deepcopy(self.profile);p['tier1']['medications'][0]['days_supply']=45
        self.assertEqual(compare_plans(p)['status'],'invalid_or_unsupported_input')
    def test_longer_profiles_and_missing_matches(self):
        for supply in (60,90):
            p=deepcopy(self.profile)
            for m in p['tier1']['medications']:
                m['days_supply']=supply;m['quantity_per_fill']=supply
            result=compare_plans(p)
            self.assertEqual(result['status'],'completed')
            good=[r for r in result['plans'] if r['annual_total'] is not None]
            self.assertTrue(good)
            for row in good:
                self.assertEqual(len(row['fill_ledger']),2*len(scheduled_dates(supply)))
                self.assertTrue(all(d['days_supply']==supply for d in row['medication_inputs']))
            if supply==60:
                bad=[r for r in result['plans'] if r['contract_id']=='S5921']
                self.assertTrue(all(r['annual_total'] is None for r in bad))
                self.assertTrue(all('payment rule' in ' '.join(r['unavailable_reasons']) for r in bad))
    def test_extra_help_rejected(self):
        for answer in ['Yes',"I don't know"]:
            p=deepcopy(self.profile);p['tier1']['extra_help_status']=answer
            self.assertEqual(compare_plans(p)['plans'],[])
    def test_duplicate_drug(self):
        p=deepcopy(self.profile);p['tier1']['medications']*=2
        self.assertIn('Duplicate medication product requires clarification',compare_plans(p)['errors'])
    def test_unknown_product(self):
        p=deepcopy(self.profile);p['tier1']['medications'][0]['ndc']='00000000000'
        self.assertEqual(compare_plans(p)['plans'],[])
    def test_wrong_pharmacy(self):
        p=deepcopy(self.profile);p['tier1']['pharmacy_location']['location_id']='fake'
        self.assertEqual(compare_plans(p)['plans'],[])
    def test_reversed_input_same_totals(self):
        p=deepcopy(self.profile);p['tier1']['medications'].reverse()
        self.assertEqual([r['annual_total'] for r in compare_plans(p)['plans']], [r['annual_total'] for r in compare_plans(self.profile)['plans']])
    def test_bad_quantity(self):
        for qty in [0,-1,float('nan'),float('inf'),True]:
            p=deepcopy(self.profile);p['tier1']['medications'][0]['quantity_per_fill']=qty
            self.assertEqual(compare_plans(p)['plans'],[])


class Robustness(unittest.TestCase):
    def test_malformed_profiles(self):
        for p in (None, [], {}, {'tier1':None}, {'tier1':[]}):
            self.assertEqual(compare_plans(p)['status'],'invalid_or_unsupported_input')
    def test_invalid_identifier_types(self):
        base=json.loads((ROOT/'evidence/integrated_intake_example.json').read_text())
        for value in ([],{},None,123):
            p=deepcopy(base);p['tier1']['medications'][0]['ndc']=value
            self.assertEqual(compare_plans(p)['status'],'invalid_or_unsupported_input')
    def test_batch_retains_rejected_profiles(self):
        from cost_engine import compare_profiles
        from development_profiles import build_profiles
        result=compare_profiles(build_profiles())
        self.assertEqual(len(result['results']),8)
        self.assertEqual(result['results']['clarification_needed']['plans'],[])
        mixed=result['results']['mixed_30_and_90_days']
        for row in mixed['plans']:
            if row['annual_total'] is not None:
                self.assertEqual(row['fill_count'],18)
                self.assertEqual(row['peak_monthly_total'],max(m['total'] for m in row['monthly_costs']))
    def test_completeness_reports_missing_longer_fills(self):
        from development_profiles import build_profiles
        result=compare_plans(build_profiles()['two_medications_60_days'])
        self.assertFalse(result['coverage_summary']['complete_comparison'])
        self.assertEqual(result['coverage_summary']['plans_considered'],12)
        for p in result['plans']:
            if p['annual_total'] is None:
                self.assertTrue(p['issue_codes'])
                self.assertNotIn('fill_ledger',p)

if __name__=='__main__':unittest.main()
