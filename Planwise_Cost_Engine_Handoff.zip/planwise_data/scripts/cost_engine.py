"""Auditable 2026 cost prototype; unavailable results never become zero estimates.

Annual means 365 calendar days of purchases: Jan 1 and every selected 30/60/90 days
(13/7/5 full fills; the last fill can carry into 2027). Only the two reviewed demonstration
products are currently enabled. See docs/COST_ENGINE.md for boundaries.
"""
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
from datetime import date, timedelta
import json
import duckdb
from intake_data import validate_selected_medications, validate_pharmacy

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / 'data/planwise.duckdb'
ZERO = Decimal('0')
CENT = Decimal('.01')
THRESHOLD = Decimal('2100')
# Reviewed source-linked oral generics. This is deliberately not a universal
# clinical classifier inferred from a name substring or an RxNorm term type.
REVIEWED_PRODUCTS = {'60505257908': '617310', '68180098003': '314076'}


def number(value):
    if value is None or isinstance(value, bool):
        raise ValueError('Missing or invalid numerical input')
    out = Decimal(str(value))
    if not out.is_finite() or out < 0:
        raise ValueError('Numbers must be finite and nonnegative')
    return out


def money(value):
    return number(value).quantize(CENT, rounding=ROUND_HALF_UP)


def scheduled_dates(days_supply=30):
    if isinstance(days_supply, bool) or days_supply not in (30, 60, 90):
        raise ValueError("Supported fill lengths are 30, 60, or 90 days")
    start = date(2026, 1, 1)
    return [start + timedelta(days=d) for d in range(0, 365, days_supply)]


def payment(gross, rule):
    """Member share cannot exceed the modeled full prescription price."""
    gross = number(gross)
    kind = str(rule['type'])
    amount = number(rule['amount'])
    minimum, maximum = number(rule['minimum']), number(rule['maximum'])
    if kind == '1':
        due = amount
    elif kind == '2':
        if amount > 1:
            raise ValueError('Coinsurance must be a fraction between zero and one')
        if maximum and minimum > maximum:
            raise ValueError('Minimum payment exceeds maximum payment')
        due = max(gross * amount, minimum)
        if maximum:  # CMS zero maximum treated as no maximum; explicit assumption.
            due = min(due, maximum)
    else:
        raise ValueError('Retail payment option not offered or unknown')
    return money(min(gross, due))


def simulate(plan, drugs):
    """Shared deductible ledger for cases safely below catastrophic threshold.

Total modeled gross covered spending is an upper bound on qualifying spending
within this restricted no-other-payer scope. Higher spending is blocked because
plan supplemental-benefit classification is absent, rather than using member
payments alone as a substitute for true out-of-pocket accumulation.
"""
    premium, deductible = money(plan['premium']), money(plan['deductible'])
    if deductible > 615:
        raise ValueError('Plan deductible exceeds the supported 2026 maximum')
    annual_gross = sum((d['gross_per_fill'] * len(scheduled_dates(d.get('days_supply', 30))) for d in drugs), ZERO)
    if annual_gross >= THRESHOLD:
        raise ValueError('annual_limit_rules_unresolved: modeled gross spending reaches $2,100; additional plan benefit information is required')
    remaining = deductible
    ledger = []
    events = [(day, d) for d in drugs for day in scheduled_dates(d.get('days_supply', 30))]
    for fill_date, drug in sorted(events, key=lambda e: (e[0], e[1]['ndc'])):
        gross = drug['gross_per_fill']
        before = remaining
        ded_paid = min(remaining, gross) if drug['deductible_applies'] else ZERO
        remaining -= ded_paid
        rest = gross - ded_paid
        # Full fixed copay on the post-deductible remainder, capped at that
        # remainder; no fractional copay assumption. See documented limit.
        rule = drug['rule']
        if before > 0 and not drug['deductible_applies']:
            rule = drug.get('pre_rule') or rule
        share = payment(rest, rule) if rest else ZERO
        due = money(ded_paid + share)
        ledger.append({'date': fill_date.isoformat(), 'ndc': drug['ndc'], 'days_supply': drug.get('days_supply', 30),
                       'medication_name': drug['medication_name'],
                       'gross_cost': gross, 'deductible_paid': ded_paid,
                       'post_deductible_payment': share, 'member_payment': due,
                       'deductible_remaining': remaining})
    medication_total = sum((r['member_payment'] for r in ledger), ZERO)
    monthly = []
    for month in range(1, 13):
        rows = [r for r in ledger if int(r['date'][5:7]) == month]
        drug_total = sum((r['member_payment'] for r in rows), ZERO)
        monthly.append({'month': month, 'premium': premium, 'medication_cost': drug_total,
                        'total': premium + drug_total})
    return {'annual_premium': premium * 12, 'annual_medication_cost': medication_total,
            'annual_total': premium * 12 + medication_total,
            'annual_gross_drug_cost': annual_gross,
            'deductible_paid': sum((r['deductible_paid'] for r in ledger), ZERO),
            'monthly_costs': monthly, 'fill_ledger': ledger,
            'fill_count': len(ledger),
            'peak_monthly_total': max(r['total'] for r in monthly),
            'average_monthly_total': money((premium * 12 + medication_total) / 12)}


def query(con, sql, args=()):
    cur = con.execute(sql, args)
    names = [x[0] for x in cur.description]
    return [dict(zip(names, row)) for row in cur.fetchall()]


def rule_from(row, channel):
    return {'type': row['cost_type_' + channel], 'amount': row['cost_amt_' + channel],
            'minimum': row['cost_min_amt_' + channel], 'maximum': row['cost_max_amt_' + channel]}


def compare_plans(intake, db=DB):
    if not isinstance(intake, dict) or not isinstance(intake.get('tier1'), dict):
        return {'status': 'invalid_or_unsupported_input', 'errors': ['Profile must contain a tier1 record'], 'plans': []}
    t = intake['tier1']
    errors = []
    if t.get('lives_in_michigan') != 'Yes': errors.append('Michigan residence must be confirmed')
    if t.get('extra_help_status') != 'No': errors.append('Only profiles without Extra Help are supported')
    meds = t.get('medications')
    if not isinstance(meds, list): meds = []; errors.append('Medication list is required')
    if meds:
        try:
            errors.extend(validate_selected_medications(meds))
        except (TypeError, KeyError, ArithmeticError):
            errors.append('Medication fields have invalid types; check identifiers, quantity and days supply')
    errors.extend(validate_pharmacy(t.get('pharmacy_location')))
    seen = set()
    for med in meds:
        if not isinstance(med, dict): continue
        if med.get('days_supply') not in (30, 60, 90): errors.append('Only 30-, 60-, and 90-day retail fills are supported')
        if med.get('assume_year_round_use') is not True: errors.append('This version requires year-round use')
        if not isinstance(med.get('ndc'), str) or not isinstance(med.get('rxcui'), str):
            errors.append('Medication identifiers must be strings'); continue
        if med.get('ndc') in seen: errors.append('Duplicate medication product requires clarification')
        seen.add(med.get('ndc'))
        if REVIEWED_PRODUCTS.get(med.get('ndc')) != med.get('rxcui'):
            errors.append('Medication needs product-specific rule review before cost calculation')
    metadata = {'plan_year': 2026, 'source_release': 'Q3 2026',
                'schedule': '2026-01-01 then each medication’s selected 30/60/90-day interval through 2026-12-31; 13/7/5 full fills respectively',
                'validation': 'Prototype: internal arithmetic checks; not independently validated against Plan Finder',
                'assumptions': ['Synthetic profile; no Extra Help or other payer contributions',
                    'In-area retail pharmacy; unchanged medications, prices and enrollment all year',
                    'Price proxy = max(unit cost × quantity + generic dispensing fee, pharmacy floor price)',
                    'All simultaneous fills processed in National Drug Code order',
                    'No drug substitution, mail order, income surcharges or late-enrollment penalties',
                    'Annual premium is separate from drug spending and deductible payments',
                    'No plan ranking or recommendation is produced'],
                'preferences': {'tier2': intake.get('tier2', {}), 'tier3': intake.get('tier3', {})}}
    if errors: return {**metadata, 'status': 'invalid_or_unsupported_input', 'errors': sorted(set(errors)), 'plans': []}
    results = []
    with duckdb.connect(str(db), read_only=True) as con:
        years = {r['contract_year'] for r in query(con, 'SELECT DISTINCT contract_year FROM clean.formulary')}
        if years != {2026}: raise ValueError('Database must contain only the 2026 formulary snapshot')
        for plan in query(con, 'SELECT * FROM clean.plans ORDER BY contract_id,plan_id,segment_id'):
            key = [plan[k] for k in ('contract_id', 'plan_id', 'segment_id')]
            output = {k: plan[k] for k in ('contract_id', 'plan_id', 'segment_id', 'plan_name', 'premium', 'deductible')}
            output.update(status='estimate_unavailable', annual_total=None, annual_medication_cost=None,
                          annual_premium=money(plan['premium']) * 12, warnings=[], unavailable_reasons=[])
            drugs = []
            try:
                if plan['plan_suppressed_yn'] != 'N': raise ValueError('Plan suppressed or suppression status unknown')
                network = query(con, 'SELECT * FROM clean.pharmacy_network WHERE contract_id=? AND plan_id=? AND segment_id=? AND pharmacy_number=?', key + [t['pharmacy_location']['pharmacy_number']])
                if meds and len(network) != 1: raise ValueError('Selected pharmacy has no unique network match')
                if meds:
                    n = network[0]
                    if n['pharmacy_retail'] != 'Y' or n['in_area_flag'] != 1: raise ValueError('An in-area retail pharmacy is required')
                    if n['preferred_status_retail'] not in ('Y', 'N'): raise ValueError('Unknown pharmacy preference status')
                    channel = 'pref' if n['preferred_status_retail'] == 'Y' else 'nonpref'
                    output['pharmacy_status'] = 'preferred' if channel == 'pref' else 'standard'
                for med in meds:
                    supply = int(med['days_supply'])
                    fee_column = f'generic_dispensing_fee_{supply}'
                    matches = query(con, '''SELECT d.*,f.selected_drug_yn FROM clean.named_plan_drugs d
                        JOIN clean.formulary f ON d.formulary_id=f.formulary_id AND d.formulary_version=f.formulary_version
                          AND d.contract_year=f.contract_year AND d.ndc=f.ndc AND d.rxcui=f.rxcui
                        WHERE d.contract_id=? AND d.plan_id=? AND d.segment_id=? AND d.ndc=? AND d.rxcui=? AND d.days_supply=?''', key + [med['ndc'], med['rxcui'], supply])
                    if len(matches) != 1: raise ValueError(f'Medication lacks unique formulary/{supply}-day price match: ' + med['ndc'])
                    d = matches[0]
                    if d['selected_drug_yn'] != 'N': raise ValueError('Negotiated selected-drug rules require separate review')
                    for flag in ('prior_authorization_yn', 'step_therapy_yn'):
                        if d[flag] != 'N': raise ValueError('Coverage restriction requires review: ' + flag + ' ' + med['ndc'])
                    if d['quantity_limit_yn'] == 'Y':
                        q, days = number(d['quantity_limit_amount']), number(d['quantity_limit_days'])
                        if days == 0 or number(med['quantity_per_fill']) / supply > q / days:
                            raise ValueError('Quantity exceeds modeled quantity limit: ' + med['ndc'])
                        output['warnings'].append('Quantity limit checked as units/day; verify dispensing-specific limit for ' + med['ndc'])
                    elif d['quantity_limit_yn'] != 'N': raise ValueError('Unknown quantity-limit flag')
                    gross = money(max(number(d['unit_cost']) * number(med['quantity_per_fill']) + number(n[fee_column]), number(n['floor_price'])))
                    rules = query(con, '''SELECT * FROM clean.cost_sharing_days WHERE contract_id=? AND plan_id=? AND segment_id=? AND tier=? AND days_supply_days=? AND coverage_level=1''', key + [d['tier'], supply])
                    if len(rules) != 1: raise ValueError(f'No unique initial-coverage payment rule for {supply} days, tier {d["tier"]}; no shorter-fill rate substituted')
                    r = rules[0]; rule = rule_from(r, channel); payment(gross, rule)
                    if r['ded_applies_yn'] not in ('Y', 'N'): raise ValueError('Unknown deductible applicability')
                    pre = query(con, '''SELECT * FROM clean.cost_sharing_days WHERE contract_id=? AND plan_id=? AND segment_id=? AND tier=? AND days_supply_days=? AND coverage_level=0''', key + [d['tier'], supply])
                    if len(pre) > 1: raise ValueError('Ambiguous pre-deductible rule')
                    pre_rule = rule_from(pre[0], channel) if pre and r['ded_applies_yn'] == 'N' else None
                    if pre_rule: payment(gross, pre_rule)
                    drugs.append({'ndc': med['ndc'], 'rxcui': med['rxcui'], 'medication_name': med['medication_name'],
                                  'quantity_per_fill': med['quantity_per_fill'], 'days_supply': supply, 'tier': d['tier'],
                                  'unit_cost': d['unit_cost'], 'dispensing_fee': n[fee_column],
                                  'floor_price': n['floor_price'], 'gross_per_fill': gross,
                                  'deductible_applies': r['ded_applies_yn'] == 'Y', 'rule': rule, 'pre_rule': pre_rule})
                output.update(simulate(plan, drugs))
                output.update(status='estimated_under_documented_assumptions', medication_inputs=drugs)
                output['warnings'].append('Uses average retail unit prices, not a pharmacy-specific price quote')
            except (ValueError, TypeError, ArithmeticError) as exc:
                output['unavailable_reasons'].append(str(exc))
            results.append(output)
    available = sum(p['annual_total'] is not None for p in results)
    for p in results:
        p['issue_codes'] = [issue_code(reason) for reason in p['unavailable_reasons']]
    return {**metadata, 'status': 'completed', 'plans': results,
            'coverage_summary': {'plans_considered': len(results), 'plans_estimated': available,
                'plans_unavailable': len(results) - available,
                'complete_comparison': available == len(results)}}


def issue_code(reason):
    """Stable categories for summary/evaluation code; retain full reason text."""
    if 'annual_limit_rules_unresolved' in reason: return 'annual_limit_rules_unresolved'
    if 'payment rule' in reason: return 'missing_payment_rule'
    if 'price match' in reason: return 'missing_or_ambiguous_drug_price'
    if 'pharmacy' in reason.lower(): return 'pharmacy_unavailable'
    if 'restriction' in reason: return 'coverage_restriction'
    if 'Quantity' in reason: return 'quantity_limit'
    return 'requires_review'


def compare_profiles(profiles):
    """Run named development profiles independently; invalid input stays visible."""
    if not isinstance(profiles, dict):
        raise ValueError('Supply a mapping of profile names to intake records')
    results = {name: compare_plans(profile) for name, profile in profiles.items()}
    summary = []
    for name, result in results.items():
        counts = result.get('coverage_summary', {})
        summary.append({'profile': name, 'status': result['status'],
                        'plans_estimated': counts.get('plans_estimated', 0),
                        'plans_unavailable': counts.get('plans_unavailable', 0),
                        'input_errors': result.get('errors', [])})
    return {'purpose': 'Development checks, not held-out evaluation',
            'summary': summary, 'results': results}


def json_default(value):
    if isinstance(value, Decimal): return str(value)
    raise TypeError(type(value).__name__)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile', type=Path, default=ROOT/'evidence/integrated_intake_example.json')
    parser.add_argument('--output', type=Path, default=ROOT/'evidence/cost_engine_example.json')
    args = parser.parse_args()
    result = compare_plans(json.loads(args.profile.read_text()))
    args.output.write_text(json.dumps(result, indent=2, default=json_default))
    for p in result['plans']:
        print(p['contract_id'], p['plan_id'], p['plan_name'], p['status'], p.get('annual_total'), p['unavailable_reasons'])
    if result.get('errors'): print(result['errors'])
