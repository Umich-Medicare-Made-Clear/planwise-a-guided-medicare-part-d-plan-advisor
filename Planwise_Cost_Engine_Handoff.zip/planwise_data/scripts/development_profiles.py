"""Reproducible development scenarios derived from the connected example.
These are variations for engineering checks, not representative beneficiaries.
"""
import json
from copy import deepcopy
from cost_engine import ROOT, compare_profiles, json_default


def build_profiles():
    base=json.loads((ROOT/'evidence/integrated_intake_example.json').read_text())
    profiles={}
    for supply in (30,60,90):
        p=deepcopy(base)
        for m in p['tier1']['medications']:
            m['days_supply']=supply
            m['quantity_per_fill']=supply
        profiles[f'two_medications_{supply}_days']=p
    p=deepcopy(base)
    p['tier1']['medications'][1].update(days_supply=90,quantity_per_fill=90)
    profiles['mixed_30_and_90_days']=p
    p=deepcopy(base);p['tier1']['medications']=p['tier1']['medications'][:1]
    profiles['one_medication']=p
    p=deepcopy(base);p['tier1']['medications']=[]
    profiles['no_medications']=p
    p=deepcopy(base);p['tier1']['medications'][0]['strength']='unknown'
    profiles['clarification_needed']=p
    p=deepcopy(base);p['tier1']['extra_help_status']='Yes'
    profiles['outside_subsidy_scope']=p
    return profiles


if __name__=='__main__':
    profiles=build_profiles()
    (ROOT/'evidence/cost_engine_development_profiles.json').write_text(json.dumps(profiles,indent=2))
    result=compare_profiles(profiles)
    (ROOT/'evidence/cost_engine_batch_results.json').write_text(json.dumps(result,indent=2,default=json_default))
    print(json.dumps(result['summary'],indent=2))
