from pathlib import Path
import nbformat as nb
R=Path(__file__).resolve().parents[1]
n=nb.v4.new_notebook()
n.metadata['kernelspec']={'display_name':'Python (Planwise)','language':'python','name':'planwise'}
n.cells=[nb.v4.new_markdown_cell('''# Planwise: Annual Cost Calculator

Rechelle Transeth · November 15, 2026

This notebook calculates a **restricted prototype estimate** for the connected synthetic profile. It is not yet independently validated or a recommendation engine.

**Supported demonstration:** two reviewed oral generic medications, 30-, 60-, and 90-day in-area retail fills, no Extra Help or other payer contributions, and modeled annual gross drug spending below $2,100. Higher-spending profiles are flagged because qualifying annual spending requires additional plan rules.

Each medication starts January 1 and repeats at its selected interval: **13, 7, or 5 fills during 2026** for 30, 60, or 90 days, respectively. Unused supply can carry into the next year. Prices are frozen to the quarterly snapshot. See `docs/COST_ENGINE.md` for assumptions and sources.'''),
nb.v4.new_code_cell('''from pathlib import Path
import json, sys
import pandas as pd
ROOT=Path.cwd()
if not (ROOT/'data/planwise.duckdb').exists(): ROOT=ROOT/'planwise_data'
assert (ROOT/'data/planwise.duckdb').exists(), 'Open from planwise_data with the prepared database.'
sys.path.insert(0,str(ROOT/'scripts'))
from cost_engine import compare_plans, json_default
from IPython.display import display
profile=json.loads((ROOT/'evidence/integrated_intake_example.json').read_text())
display(pd.DataFrame(profile['tier1']['medications']))
print(profile['tier1']['pharmacy_location']['location_name'])'''),
nb.v4.new_markdown_cell('''## Plan comparisons
Annual medication expenses already include deductible payments. Annual total = annual premium + annual medication expenses. The rows are in plan-identifier order, not recommendation order. An unavailable estimate must not be treated as zero.'''),
nb.v4.new_code_cell('''result=compare_plans(profile)
assert result['status']=='completed',result.get('errors')
columns=['plan_name','pharmacy_status','annual_premium','annual_medication_cost','deductible_paid','annual_total','status']
display(pd.DataFrame([{k:p.get(k) for k in columns} for p in result['plans']]))
(ROOT/'evidence/cost_engine_example.json').write_text(json.dumps(result,indent=2,default=json_default))
print('Plans with estimates:',sum(p['status']=='estimated_under_documented_assumptions' for p in result['plans']))'''),
nb.v4.new_markdown_cell('''## Follow one plan through the year
The first plan below is an example, not a selected recommendation. December can include two fills because the schedule is every 30 days, not once per calendar month.'''),
nb.v4.new_code_cell('''example=next(p for p in result['plans'] if p['status']=='estimated_under_documented_assumptions')
print(example['plan_name'])
display(pd.DataFrame(example['medication_inputs'])[['medication_name','tier','unit_cost','dispensing_fee','gross_per_fill','deductible_applies']])
display(pd.DataFrame(example['monthly_costs']))
display(pd.DataFrame(example['fill_ledger']).head(6))'''),
nb.v4.new_markdown_cell("""## Compare all three fill lengths
These examples assume one tablet per day, so quantity is explicitly 30, 60, or 90 tablets. Each run uses the matching supply-specific price, dispensing fee, and payment rule. Unavailable combinations remain visible; a 30-day rate is never substituted. Real profiles must supply their actual quantity, not an inferred dosage."""),
nb.v4.new_code_cell("""from copy import deepcopy
supply_rows=[]
for supply in (30,60,90):
    variant=deepcopy(profile)
    for medication in variant['tier1']['medications']:
        medication['days_supply']=supply
        medication['quantity_per_fill']=supply
    comparison=compare_plans(variant)
    (ROOT/f'evidence/cost_engine_{supply}_day_example.json').write_text(json.dumps(comparison,indent=2,default=json_default))
    for plan in comparison['plans']:
        supply_rows.append({'days_supply':supply,'plan_name':plan['plan_name'],'annual_total':plan['annual_total'],'status':plan['status'],'reason':'; '.join(plan['unavailable_reasons'])})
display(pd.DataFrame(supply_rows))"""),
nb.v4.new_markdown_cell('''## Unsupported inputs stay visible
This example changes a fill to an unsupported 45 days. The calculator rejects it rather than converting the supply or inventing a payment.'''),
nb.v4.new_code_cell('''from copy import deepcopy
unsupported=deepcopy(profile)
unsupported['tier1']['medications'][0]['days_supply']=45
blocked=compare_plans(unsupported)
print(blocked['status'])
print(*blocked['errors'],sep='\\n')'''),
nb.v4.new_markdown_cell('''## Validation and remaining work
The checks below test arithmetic and data integration. They do not establish agreement with real pharmacy quotes or Medicare Plan Finder.

Remaining work: independently validate price construction and deductible-crossing claims; implement qualifying annual-spending rules for higher-cost profiles; review additional medication products. Insulin, vaccines, mail order, and subsidized estimates are not enabled.'''),
nb.v4.new_code_cell('''import unittest, io
suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_cost_engine.py')
stream=io.StringIO()
run=unittest.TextTestRunner(stream=stream,verbosity=1).run(suite)
print(stream.getvalue())
assert run.wasSuccessful()
checks={'tests_run':run.testsRun,'failures':len(run.failures),'errors':len(run.errors),'external_validation':False}
(ROOT/'evidence/cost_engine_checks.json').write_text(json.dumps(checks,indent=2))''')]
n.cells[10:10]=[
nb.v4.new_markdown_cell("""## Development checks
Eight reproducible scenarios exercise the connection, including mixed fill lengths and inputs that need clarification. These variations use the same two reviewed medications; they are not a representative population or the final evaluation set.

The completeness counts show when some plans cannot be estimated. Missing estimates are never treated as inexpensive plans. Peak monthly spending is a modeled amount under the fixed fill schedule, not a promise of predictable real-world costs."""),
nb.v4.new_code_cell("""from development_profiles import build_profiles
from cost_engine import compare_profiles
profiles=build_profiles()
batch=compare_profiles(profiles)
display(pd.DataFrame(batch['summary']))
(ROOT/'evidence/cost_engine_development_profiles.json').write_text(json.dumps(profiles,indent=2))
(ROOT/'evidence/cost_engine_batch_results.json').write_text(json.dumps(batch,indent=2,default=json_default))
mixed=batch['results']['mixed_30_and_90_days']
display(pd.DataFrame([{k:p.get(k) for k in ['plan_name','annual_total','fill_count','average_monthly_total','peak_monthly_total','issue_codes']} for p in mixed['plans']]))
print('Mixed-fill completeness:',mixed['coverage_summary'])""")]
nb.write(n,R/'Planwise_Cost_Engine.ipynb')
