# Initial annual cost calculator

Built November 14, 2026. This is a restricted, inspectable prototype, not a validated recommendation engine. The earlier integration notebooks remain unchanged.

## What works

The calculator accepts the connected intake's `tier1`, `tier2`, and `tier3` record. It validates the medication identifiers and pharmacy selection, queries the prepared DuckDB database, and returns one result for each of the 12 selected Michigan plans. Preferences are retained for later summary generation; they do not change arithmetic or rank plans.

For supported records it calculates annual premiums, estimated member medication expenses, deductible payments, monthly totals, and a dated fill ledger. A single deductible balance is shared across all medications. Deductible payments are already included in medication expenses; the deductible is not added a second time to the total.

## Explicit starting scope

- 2026 Michigan stand-alone plans; no Extra Help, other payer contributions, surcharges, or penalties.
- 30-, 60-, and 90-day in-area retail fills at a pharmacy from the demonstration directory.
- Full-year enrollment and continued medication use with no changes.
- Two reviewed generic oral products only: atorvastatin 20 mg, National Drug Code 60505257908 / RxNorm identifier 617310; lisinopril 10 mg, National Drug Code 68180098003 / RxNorm identifier 314076.
- New products require explicit review of special payment rules and fee classification before enabling. This deliberately does not infer that any medication is safe to price just from its name.
- Insulin, vaccines, selected negotiated drugs, supplemental excluded drugs, and indication-dependent coverage are not enabled.
- Prior authorization or step therapy produces an unavailable estimate pending review. Quantity limits are checked as units per day and produce a warning even when the check passes; dispensing-specific limits need external confirmation.

## Schedule and prices

The calendar model starts January 1 and refills every 30 days through December 31: **13 full purchases**, with the final December 27 fill partly used in 2027. This estimates purchases during the calendar year, not exactly 365 days of medication consumption. It is not a 12-month/360-day shortcut. Changing the starting inventory or first-fill date is not yet supported.

Estimated prescription price = max(average CMS retail unit price × quantity + generic dispensing fee for the selected supply length, pharmacy floor price). This combination is a documented modeling assumption using the source field meanings; it has not been independently validated against Plan Finder. It is not an exact pharmacy quote. Prices are frozen to Q3 2026 throughout the modeled year.

Preferred/standard retail status selects the applicable payment columns. Copays are capped at modeled prescription price. Coinsurance uses the source fraction, applies the stated minimum and positive maximum, then caps at price. A zero maximum is treated as no upper bound; this interpretation requires comparison-case validation.

When an applicable deductible is crossed within a fill, the deductible portion is paid first and the payment rule applies to the remaining price. A fixed copay is not prorated, but cannot exceed that remainder. This boundary convention requires external validation. For a deductible-exempt tier, the explicit pre-deductible rule is used when available; otherwise the initial rule is used. Simultaneous fills are processed in National Drug Code order. This is reproducible, but the actual pharmacy processing order can differ.

## Annual spending limit: deliberately incomplete

CMS sets the 2026 qualifying out-of-pocket threshold at $2,100 and the standard deductible at $615. The plan's own deductible and tier exemptions come from the database.

**Qualifying spending is not necessarily identical to member payments.** Supplemental plan benefits can contribute, and the current plan table lacks benefit-design classification and all information needed to implement that accumulation reliably.

The prototype therefore returns `estimate_unavailable` whenever the total modeled annual gross covered prescription spending reaches $2,100. Below that amount, within the restricted no-other-payer scenario, even the gross spending cannot reach the threshold. This is a conservative scope check, not an implementation of catastrophic coverage and not a claim that a member must pay $2,100. High-spending cases still need benefit-design data and verified threshold-crossing logic. Premiums are excluded from this check.

## Output contract

`compare_plans(intake)` returns a top-level status, scope/assumptions, unchanged explanation preferences, and a `plans` list. Each plan includes identifiers, plan name, monthly premium, deductible, status, annual premium, annual medication cost, annual total, warnings, and unavailable reasons. Successful results include `medication_inputs`, `monthly_costs`, and `fill_ledger`.

Money is calculated with Decimal and serialized as decimal strings. Unavailable medication expenses and annual totals are `null`, never zero. A genuine zero is permitted only from a successful calculation. There is no ranking; consumers must not sort unavailable totals as zero or call the cheapest output a verified recommendation.

## Run and test

From the extracted `planwise_data` directory in the prepared Python environment:

```sh
python scripts/cost_engine.py
python -m unittest discover -s tests -v
```

Default input: `evidence/integrated_intake_example.json`.
Default output: `evidence/cost_engine_example.json`.
For another validated profile: `python scripts/cost_engine.py --profile PATH --output PATH`.

The initial suite contains 25 passing tests covering manual arithmetic expectations, one shared deductible, zero-drug/single-drug/multiple-drug profiles, monthly/annual reconciliation, retail payment rules, input rejection, and high-spending blocking. These are internal tests, not independent external validation.

## Next implementation and team handoff

1. Alex: independently work sample calculations, including boundary claims, and document aligned Plan Finder comparisons if available.
2. Taylor: prepare additional synthetic profiles, keeping product review and missing-input flags visible.
3. Rechelle: validate the price construction and payment boundaries; obtain benefit-design information and implement qualifying-spending accumulation; review and enable more medications.
4. Meagan: use the returned cost components and status/warnings as summary inputs. Do not present unavailable estimates as complete.

## Primary references checked November 14, 2026

- CMS final 2026 benefit instructions: https://www.cms.gov/newsroom/fact-sheets/final-cy-2026-part-d-redesign-program-instructions
- Full final 2026 instructions (HHS copy): https://www.hhs.gov/guidance/sites/default/files/hhs-guidance-documents/CMS/final_calendar_year_2026_part_d_redesign_program_instructions_g.pdf
- CMS final 2025 instructions (continuing supplemental-benefit treatment): https://www.cms.gov/files/document/final-cy-2025-part-d-redesign-program-instructions.pdf
- CMS 2026 quarterly-file methodology: https://data.cms.gov/sites/default/files/2025-10/cf6b8476-ca42-48c6-9fc4-281b08c6ea87/Methodology-SPUF-2026.pdf
- CMS record layout: https://data.cms.gov/sites/default/files/2025-10/83da019f-fa24-483e-87de-cc089780a6a5/SPUFRecordLayout-2026.pdf
- Frozen download provenance: `evidence/download_manifest.json`.

## Supply-length update

All three fill lengths are supported when the selected plan/product has matching price and payment records. Supply-specific prices and fees are used. A profile may mix fill lengths; claims are processed in chronological order against one shared deductible. Quantity is always supplied explicitly. Unmatched longer-fill combinations remain unavailable; no 30-day extrapolation is used. The example notebook demonstrates all three lengths.


## November 15: expanded development checks

The batch entry point `compare_profiles` accepts a dictionary of named intake
profiles and preserves both successful and rejected profiles. The reproducible
scenario builder is `scripts/development_profiles.py`. Its eight cases cover
30-, 60-, and 90-day fills; mixed 30/90-day fills; one medication; no medications;
incorrect strength needing clarification; and an Extra Help response outside scope.
These are engineering variations of the connected example, not new clinically
representative personas or held-out evaluation cases.

Each comparison now includes `coverage_summary`: plans considered, estimated,
unavailable, and whether the comparison is complete. Each unavailable plan has
`issue_codes` plus the full reason. Available plans include `fill_count`,
`average_monthly_total`, and `peak_monthly_total`. The average is annual total
divided by 12, rounded to cents; the peak comes from the actual modeled monthly
ledger. Neither is a user budget check. Missing totals remain null.

Malformed top-level profiles and invalid medication identifier types return
input errors. Internal checks now include batch isolation, mixed schedules,
completeness reporting and monthly summaries. The notebook writes the current
test count to `evidence/cost_engine_checks.json`.

Still unresolved: additional product review beyond the two enabled medications,
higher-spending annual coverage rules, independent validation of price assumptions,
and unavailable supply-specific payment rules. This expansion does not remove
those limits or establish agreement with Medicare Plan Finder.
