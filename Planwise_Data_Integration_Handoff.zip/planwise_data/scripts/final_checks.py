from pathlib import Path
import duckdb,json
R=Path(__file__).resolve().parents[1];c=duckdb.connect(str(R/'data/planwise.duckdb'))
c.execute('''CREATE OR REPLACE VIEW clean.plan_drug_cost_inputs AS
SELECT d.*,s.coverage_level,s.cost_type_pref,s.cost_amt_pref,s.cost_type_nonpref,s.cost_amt_nonpref,s.ded_applies_yn,
CASE WHEN d.unit_cost IS NULL THEN 'missing_price' WHEN s.coverage_level IS NULL THEN 'missing_cost_sharing' ELSE 'joined_not_annual_estimate' END AS input_status
FROM clean.named_plan_drugs d LEFT JOIN clean.cost_sharing_days s
ON d.contract_id=s.contract_id AND d.plan_id=s.plan_id AND d.segment_id=s.segment_id AND d.tier=s.tier AND d.days_supply=s.days_supply_days AND s.coverage_level=1''')
p=R/'evidence/quality_checks.json';qa=json.loads(p.read_text())
for t,cols in [('insulin_cost','contract_id,plan_id,segment_id,tier,days_supply'),('excluded_drugs','contract_id,plan_id,rxcui'),('indications','contract_id,plan_id,rxcui,disease')]:
 qa[t+'_duplicate_keys']=c.execute(f'SELECT count(*) FROM (SELECT {cols},count(*) n FROM clean.{t} GROUP BY ALL HAVING count(*)>1)').fetchone()[0]
qa['priced_drug_rows_without_initial_cost_sharing']=c.execute("SELECT count(*) FROM clean.plan_drug_cost_inputs WHERE input_status='missing_cost_sharing'").fetchone()[0]
qa['thirty_day_rows_without_initial_cost_sharing']=c.execute("SELECT count(*) FROM clean.plan_drug_cost_inputs WHERE input_status='missing_cost_sharing' AND days_supply=30").fetchone()[0]
qa['joined_rows']=c.execute('SELECT count(*) FROM clean.plan_drug_cost_inputs').fetchone()[0]
qa['join_row_multiplication']=qa['joined_rows']-c.execute('SELECT count(*) FROM clean.plan_drug_prices').fetchone()[0]
assert qa['join_row_multiplication']==0
assert qa['thirty_day_rows_without_initial_cost_sharing']==0
for k,v in qa.items():
 if k.endswith(('_duplicate_keys','_missing_keys','_bad_width','_bad_format')):assert v==0,(k,v)
cur=c.execute('''SELECT contract_id,plan_id,days_supply,tier,count(*) AS rows FROM clean.plan_drug_cost_inputs WHERE input_status='missing_cost_sharing' GROUP BY ALL ORDER BY ALL''')
gaps=[dict(zip([x[0] for x in cur.description],r)) for r in cur.fetchall()]
(R/'evidence/cost_sharing_gaps.json').write_text(json.dumps(gaps,indent=2));p.write_text(json.dumps(qa,indent=2))
c.close()
with duckdb.connect(str(R/'data/planwise.duckdb'),read_only=True) as reopened:
 assert reopened.execute('SELECT count(*) FROM clean.plans').fetchone()[0]==12
print('Final checks passed; unresolved longer-supply cost sharing remains explicitly flagged.')
