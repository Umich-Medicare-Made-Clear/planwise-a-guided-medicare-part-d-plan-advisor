from pathlib import Path
import json,hashlib,datetime,shutil
from remotezip import RemoteZip
R=Path(__file__).resolve().parents[1]; OLD=R.parent/'rechelle_week1'
meta_path=R/'evidence/selected_release.json'
if not meta_path.exists(): meta_path=OLD/'evidence/selected_release.json'
meta=json.loads(meta_path.read_text()); url=meta['distribution'][0]['downloadURL']
entries=[]
with RemoteZip(url,timeout=180) as z:
 for i in z.infolist():
  if i.is_dir() or 'sample' in i.filename: continue
  dest=R/'data/raw'/Path(i.filename).name
  if not dest.exists():
   previous=OLD/'data'/dest.name
   if previous.exists(): shutil.copy2(previous,dest)
   else:
    print('Downloading',i.filename,flush=True)
    with z.open(i.filename) as src, dest.with_suffix('.partial').open('wb') as out:
     shutil.copyfileobj(src,out,8*1024*1024)
    dest.with_suffix('.partial').rename(dest)
  assert dest.stat().st_size==i.file_size
  h=hashlib.sha256()
  with dest.open('rb') as f:
   for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
  entries.append(dict(file=dest.name,bytes=dest.stat().st_size,sha256=h.hexdigest(),source_url=url,archive_member=i.filename,plan_year=2026,release='Q3 2026',verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
  (R/'evidence/download_manifest.json').write_text(json.dumps(entries,indent=2))
  print('Ready',dest.name,dest.stat().st_size,flush=True)
(R/'evidence/selected_release.json').write_text(json.dumps(meta,indent=2))
