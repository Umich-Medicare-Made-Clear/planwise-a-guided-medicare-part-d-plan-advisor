from lookup import match_medication

def run():
 assert match_medication('')['status']=='unmatched'
 assert match_medication('zzzz-no-drug-zzzz')['status']=='unmatched'
 partial=match_medication('atorvastatin')
 assert partial['status']=='needs_clarification' and len(partial['candidates'])>1
 assert match_medication('123','ndc')['status']=='needs_clarification'
 exact=match_medication('atorvastatin 20 MG Oral Tablet')
 assert exact['status'] in ['matched','needs_ndc_selection']
 for ndc in exact['ndc_candidates'][:3]:
  result=match_medication(ndc,'ndc')
  assert result['status']=='matched'
  assert result['candidates'][0]['rxcui']==exact['candidates'][0]['rxcui']
 print('Lookup checks passed: empty, unknown, ambiguous strength, invalid NDC, exact name and NDC round-trip.')
if __name__=='__main__':run()
