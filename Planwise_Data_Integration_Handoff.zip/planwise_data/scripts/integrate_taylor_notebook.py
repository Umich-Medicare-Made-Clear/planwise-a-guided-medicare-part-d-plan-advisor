from pathlib import Path
import nbformat as nbf
R=Path(__file__).resolve().parents[1]
n=nbf.read(R/'reference/Taylor_Intake_v2_original.ipynb',as_version=4)
n.cells[0].source+='''

## Connected CMS version
Taylor’s Tier 1–3 questions and record structure are retained. The catalog now includes 4,261 CMS-linked medication concepts, and the pharmacy list contains 20 verified Michigan locations for the demonstration. Original notebook: `reference/Taylor_Intake_v2_original.ipynb`.

Open from `planwise_data`, select the project Python environment, and Run All. The example runs offline using cached references. Other medications may need an explicit RxTerms lookup (`medication_details(rxcui, allow_network=True)`) for structured strength/form before selection. Pharmacy search is exact-ZIP within a limited directory, not a complete statewide or distance search. The result is data linkage, not a validated annual cost estimate.
'''
setup='''from pathlib import Path
import sys, json
ROOT=Path.cwd()
if not (ROOT/'data/planwise.duckdb').exists(): ROOT=ROOT/'planwise_data'
assert (ROOT/'data/planwise.duckdb').exists(), 'Open from planwise_data with its prepared database.'
sys.path.insert(0,str(ROOT/'scripts'))
from intake_data import (load_catalogs, select_medication, medication_details, ndc_choices,
                         valid_quantity_and_days, validate_selected_medications,
                         validate_pharmacy, plan_input_preview)
'''
s=n.cells[2].source
start=s.index('def valid_quantity_and_days(');end=s.index('def search_medications(',start)
s=s[:start]+"# Connected source-backed catalogs; numerical validation is imported from intake_data.\nMEDICATION_CATALOG, PHARMACY_LOCATIONS = load_catalogs()\n\n"+s[end:]
s=setup+s
s=s.replace('import pandas as pd','import pandas as pd\npd.set_option(\"display.max_columns\", None)\npd.set_option(\"display.max_rows\", 100)')
s=s.replace('str(zip_code)]','str(zip_code).strip()]')
s += '\nprint(f"Loaded {len(MEDICATION_CATALOG):,} medications and {len(PHARMACY_LOCATIONS)} pharmacy locations.")'
n.cells[2].source=s
s=n.cells[9].source
s=s.replace('for i, med in enumerate(medications, start=1):','for i, med in enumerate(medications, start=1):\n            if not isinstance(med, dict):\n                errors.append(f"Medication {i} must be a record.")\n                continue')
s=s.replace('    if not isinstance(pharmacy_location, dict)', '        errors.extend(validate_selected_medications(medications))\n\n    errors.extend(validate_pharmacy(pharmacy_location))\n    if not isinstance(pharmacy_location, dict)')
s=s.replace('raise ValueError("\\\\n".join(errors))','raise ValueError("\\n".join(errors))')
s=s.replace('"In scope for unsubsidized MVP estimate"','"Eligible for unsubsidized data checks; annual estimate not yet implemented"')
s=s.replace('"zip_used_to_filter_statewide_pdp_plans": False,','"zip_used_to_filter_statewide_pdp_plans": False,\n            "annual_cost_engine_validated": False,')
n.cells[9].source=s
n.cells[10].source='''## Example synthetic profile with real catalog selections

The member is fictional. The medication codes and pharmacy location are real, source-linked selections. This example explicitly selects two products and uses 30 units for 30 days; it does not infer a dose or recommend either drug. ZIP 48001 is used for the synthetic Michigan example. Taylor’s original 04817 remains only as a five-digit-format test, not a verified Michigan location.'''
n.cells[11].source='''# Inspect choices before selecting; incomplete names are not automatic matches.
display(pd.DataFrame(search_medications("atorvastatin 20 MG")))
display(pd.DataFrame(pharmacies_for_zip("48001")))
selected_pharmacy = next(p for p in PHARMACY_LOCATIONS if p['location_id']=='101649470568')
synthetic_member = create_intake_record(
    lives_in_michigan="Yes",
    zip_code="48001",
    medications=[
        select_medication("617310", quantity_per_fill=30, days_supply=30, ndc="60505257908"),
        select_medication("314076", quantity_per_fill=30, days_supply=30, ndc="68180098003"),
    ],
    pharmacy_location=selected_pharmacy,
    extra_help_status="No",
    first_time_part_d="Yes",
    consider_another_retail_pharmacy="Not sure",
    explanation_focus="Balanced overview",
)
synthetic_member'''
n.cells[14].source=n.cells[14].source.replace('- Show estimated annual total alongside monthly premium.','- Once validated annual estimates are available, show them alongside monthly premium. The current integration returns data inputs only.')
n.cells=[c for c in n.cells if c.source.strip()]
n.cells.extend([
nbf.v4.new_markdown_cell('''## Connected plan data

Each selected medication is checked against every Michigan plan and the selected pharmacy. Missing coverage/supply/network records remain explicit. Prescription quantities are retained as inputs but are not turned into annual costs here. All restriction flags still require interpretation. `joined_not_annual_estimate` means the input join succeeded, not that coverage conditions are satisfied or that a recommendation has been made.'''),
nbf.v4.new_code_cell('''linked_inputs = plan_input_preview(synthetic_member)
assert len(linked_inputs)==24  # two medications across twelve plans
display(pd.DataFrame(linked_inputs))
print(pd.Series([r['data_status'] for r in linked_inputs]).value_counts().to_string())
(ROOT/'evidence/integrated_intake_example.json').write_text(json.dumps(synthetic_member,indent=2))
(ROOT/'evidence/integrated_intake_plan_inputs.json').write_text(json.dumps(linked_inputs,indent=2,default=str))'''),
nbf.v4.new_markdown_cell('''## Integration validation

These checks reject identifiers inconsistent with their labels, mismatched drug/NDC selections, invalid numerical entries, unsupported days supplied, and unknown pharmacy locations. Extra Help Yes/unknown blocks the data handoff for cost use. The existing explanation preferences and first-time-user answer remain in the tiered record.'''),
nbf.v4.new_code_cell('''from copy import deepcopy

def arguments(member):
    return {**deepcopy(member['tier1']), **deepcopy(member['tier2']), **deepcopy(member['tier3'])}

checks=[]
def rejected(label, change):
    args=arguments(synthetic_member)
    change(args)
    try:
        create_intake_record(**args)
    except ValueError:
        checks.append({'test':label,'result':'PASS'});return
    raise AssertionError(label+' was incorrectly accepted')

rejected('Unknown pharmacy',lambda a:a['pharmacy_location'].update(location_id='invented'))
rejected('Mismatched drug NDC',lambda a:a['medications'][0].update(ndc='68180098003'))
rejected('Incorrect strength',lambda a:a['medications'][0].update(strength='999 mg'))
rejected('Missing drug identifiers',lambda a:a['medications'][0].update(rxcui=None,ndc=None))
rejected('Nonfinite quantity',lambda a:a['medications'][0].update(quantity_per_fill=float('inf')))
rejected('Fractional days',lambda a:a['medications'][0].update(days_supply=30.5))
rejected('Unsupported days',lambda a:a['medications'][0].update(days_supply=45))
rejected('Non-Michigan residence',lambda a:a.update(lives_in_michigan='No'))
rejected('Invalid explanation option',lambda a:a.update(explanation_focus='invented'))
for answer in ['Yes', "I don't know"]:
    args=arguments(synthetic_member);args['extra_help_status']=answer
    record=create_intake_record(**args)
    assert plan_input_preview(record)==[]
    checks.append({'test':'Extra Help '+answer+' blocks cost handoff','result':'PASS'})
assert synthetic_member['tier1']['first_time_part_d']=='Yes'
assert synthetic_member['tier2']['consider_another_retail_pharmacy']=='Not sure'
assert synthetic_member['tier3']['explanation_focus']=='Balanced overview'
checks.append({'test':'All three tiers preserved','result':'PASS'})
display(pd.DataFrame(checks))
(ROOT/'evidence/intake_integration_checks.json').write_text(json.dumps(checks,indent=2))''')])
for c in n.cells:
 if c.cell_type=='code':c.outputs=[];c.execution_count=None
n.metadata['kernelspec']={'display_name':'PlanWise (.venv)','language':'python','name':'planwise'}
nbf.write(n,R/'PlanWise_Intake_CMS_Connected.ipynb')
