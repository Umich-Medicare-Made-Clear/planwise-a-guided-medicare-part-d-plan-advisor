"""Deterministic intake lookup: suggestions never become silent matches."""
from pathlib import Path
import duckdb,re
DB=Path(__file__).resolve().parents[1]/'data/planwise.duckdb'
def match_medication(query,kind='name',limit=20):
 query=str(query).strip()
 if not query:return {'status':'unmatched','reason':'Medication entry is empty','candidates':[]}
 if kind not in ('name','rxcui','ndc'):raise ValueError('kind must be name, rxcui, or ndc')
 with duckdb.connect(str(DB),read_only=True) as con:
  base='SELECT DISTINCT rxcui,name,tty FROM clean.drug_catalog'
  if kind=='ndc':
   if not re.fullmatch(r'\d{11}',query):return {'status':'needs_clarification','reason':'Provide an unambiguous 11-digit CMS NDC','candidates':[]}
   found=con.execute(base+' WHERE rxcui IN (SELECT rxcui FROM clean.formulary WHERE ndc=?)',[query]).fetchall()
  elif kind=='rxcui':found=con.execute(base+' WHERE rxcui=?',[query]).fetchall()
  else:
   found=con.execute(base+' WHERE lower(name)=lower(?)',[query]).fetchall()
   if not found:
    found=con.execute(base+' WHERE contains(lower(name),lower(?)) ORDER BY name LIMIT ?',[query,limit]).fetchall()
    return {'status':'needs_clarification' if found else 'unmatched','reason':'Select exact strength, form and brand from candidates; no automatic substitution','candidates':[dict(zip(['rxcui','name','tty'],x)) for x in found]}
  candidates=[dict(zip(['rxcui','name','tty'],x)) for x in found]
  if not found:return {'status':'unmatched','candidates':[]}
  if len(found)>1:return {'status':'needs_clarification','candidates':candidates}
  if not found[0][1]:return {'status':'name_unresolved','candidates':candidates}
  ndcs=[x[0] for x in con.execute('SELECT DISTINCT ndc FROM clean.formulary WHERE rxcui=? ORDER BY ndc',[found[0][0]]).fetchall()]
  if kind=='ndc':ndcs=[query]
  return {'status':'matched' if len(ndcs)==1 else 'needs_ndc_selection','candidates':candidates,'ndc_candidates':ndcs}
