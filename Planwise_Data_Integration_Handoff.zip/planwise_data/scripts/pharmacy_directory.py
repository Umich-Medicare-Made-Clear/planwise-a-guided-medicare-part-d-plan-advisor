"""Fetch a bounded, explicit set of 20 pharmacy labels for the intake demo."""
from pathlib import Path
import duckdb,requests,json,time,datetime
R=Path(__file__).resolve().parents[1];folder=R/'data/reference/nppes';folder.mkdir(parents=True,exist_ok=True)
con=duckdb.connect(str(R/'data/planwise.duckdb'))
# These ZIP prefixes are used only to prioritize lookup candidates; NPPES state is verified below.
rows=con.execute("SELECT DISTINCT pharmacy_number,pharmacy_zipcode,substr(pharmacy_number,3) npi FROM clean.pharmacy_network WHERE regexp_full_match(pharmacy_number,'10[0-9]{10}') AND pharmacy_retail='Y' AND (pharmacy_zipcode LIKE '48%' OR pharmacy_zipcode LIKE '49%') ORDER BY pharmacy_zipcode,pharmacy_number LIMIT 30").fetchall()
entries=[];audit=[]
for number,zipcode,npi in rows:
 if len(entries)>=20:break
 url=f'https://npiregistry.cms.hhs.gov/api/?version=2.1&number={npi}'
 p=folder/(npi+'.json')
 try:
  if not p.exists():
   response=requests.get(url,timeout=45);response.raise_for_status();p.write_text(json.dumps(response.json(),indent=2));time.sleep(.25)
  payload=json.loads(p.read_text());result=next((x for x in payload.get('results',[]) if str(x.get('number'))==npi),None)
  if not result:
   audit.append(dict(npi=npi,status='not_found',url=url));continue
  address=next((a for a in result.get('addresses',[]) if a.get('address_purpose')=='LOCATION' and a.get('state')=='MI'),None)
  if not address:
   audit.append(dict(npi=npi,status='no_MI_location',url=url));continue
  b=result.get('basic',{});name=b.get('organization_name') or ' '.join(filter(None,[b.get('first_name'),b.get('last_name')]))
  entries.append(dict(pharmacy_number=number,npi=npi,source_network_zip=zipcode,name=name,address=address.get('address_1'),city=address.get('city'),state=address.get('state'),postal_code=address.get('postal_code'),nppes_status=b.get('status'),source_url=url,retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
  audit.append(dict(npi=npi,status='mapped',url=url))
 except Exception as exc:audit.append(dict(npi=npi,status='lookup_error',error=str(exc),url=url))
con.execute('CREATE OR REPLACE TABLE clean.pharmacy_directory(pharmacy_number VARCHAR,npi VARCHAR,source_network_zip VARCHAR,name VARCHAR,address VARCHAR,city VARCHAR,state VARCHAR,postal_code VARCHAR,nppes_status VARCHAR,source_url VARCHAR,retrieved_utc VARCHAR)')
if entries:con.executemany('INSERT INTO clean.pharmacy_directory VALUES (?,?,?,?,?,?,?,?,?,?,?)',[list(x.values()) for x in entries])
con.close()
(R/'evidence/pharmacy_directory_sample.json').write_text(json.dumps(entries,indent=2))
(R/'evidence/pharmacy_directory_audit.json').write_text(json.dumps(audit,indent=2))
print('Verified current Michigan directory labels:',len(entries),'of',len(audit),'lookups; not a full historical directory.',flush=True)
