from pathlib import Path
import nbformat as nbf
R=Path(__file__).resolve().parents[1];cells=[]
def md(s):cells.append(nbf.v4.new_markdown_cell(s))
def code(s):cells.append(nbf.v4.new_code_cell(s))
md('''# Planwise: CMS Data Integration Review
**Rechelle Transeth — November 7, 2026**

Scope: Michigan stand-alone Medicare Part D plans, Q3 2026. This review documents complete component downloads, cleaned Michigan tables, join checks, medication-name mapping, and the intake data contract. It does not implement or validate a complete annual cost engine.

Open from the `planwise_data` folder, select the Python environment containing DuckDB and Jupyter, then Run All. Saved outputs support review without running code. Rebuilding the database uses the scripts described in the README; this notebook performs read-only validation against the saved database.''')
code('''from pathlib import Path
import json, html, sys
import duckdb
from IPython.display import display, HTML, Markdown
ROOT=Path.cwd()
if not (ROOT/'data/planwise.duckdb').exists(): ROOT=ROOT/'planwise_data'
assert (ROOT/'data/planwise.duckdb').exists(), 'Open from planwise_data after building the database.'
sys.path.insert(0,str(ROOT/'scripts'))
from lookup import match_medication
E=ROOT/'evidence'
def table(rows):
    if not rows:
        print('No records.');return
    headers=list(rows[0]);body=''.join('<tr>'+''.join('<td>'+html.escape(str(r.get(k,'')))+'</td>' for k in headers)+'</tr>' for r in rows)
    display(HTML('<div style="overflow-x:auto"><table><thead><tr>'+''.join('<th>'+html.escape(k)+'</th>' for k in headers)+'</tr></thead><tbody>'+body+'</tbody></table></div>'))
def query(sql,params=None):
    with duckdb.connect(str(ROOT/'data/planwise.duckdb'),read_only=True) as c:
        cur=c.execute(sql,params or [])
        return [dict(zip([x[0] for x in cur.description],r)) for r in cur.fetchall()]
print('DuckDB',duckdb.__version__)''')
md('''## 1. Required files and provenance

The full pricing component and all six pharmacy-network components are downloaded, alongside plan, geographic, basic formulary, cost-sharing, insulin, excluded-drug and indication files. Original ZIPs are retained. The table distinguishes nationwide scanned rows from Michigan-scoped rows. Benefit year is 2026; the release covers July–September and was published in October.

[CMS quarterly data source](https://data.cms.gov/provider-summary-by-type-of-service/medicare-part-d-prescribers/quarterly-prescription-drug-plan-formulary-pharmacy-network-and-pricing-information) · [CMS field definitions](https://data.cms.gov/sites/default/files/2025-10/83da019f-fa24-483e-87de-cc089780a6a5/SPUFRecordLayout-2026.pdf)''')
code('''manifest=json.loads((E/'download_manifest.json').read_text())
table([{k:r[k] for k in ['file','bytes','plan_year','release']} for r in manifest])
audit=json.loads((E/'load_audit.json').read_text())
table(audit['sources'])
table([dict(table=k,raw_scoped_rows=v['raw_scoped_rows'],clean_rows=v['clean_rows'],exact_duplicates=v['exact_duplicates']) for k,v in audit['tables'].items()])''')
md('''## 2. Quality checks and schemas

Identifiers remain strings; column names and whitespace are normalized. Numeric conversions are audited. Exact duplicates are removed, while conflicting logical keys are reported rather than arbitrarily resolved. Cost-sharing days-supply codes are mapped explicitly; code 3 (other) is left unresolved. Missing values are not zero costs.''')
code('''checks=json.loads((E/'quality_checks.json').read_text())
table([{'check':k,'result':v} for k,v in checks.items()])
for name,stats in audit['tables'].items():
    display(Markdown('**'+name+'**'))
    table([{'field':col,'type':typ,'missing_rows':stats['null_counts'].get(col,0),'numeric_parse_failures':stats['numeric_conversion_failures'].get(col,0),'source_period_markers':stats.get('numeric_missing_markers',{}).get(col,0)} for col,typ in stats['schema']])''')
md('''## 3. Coverage of Michigan plans

The selection uses S contracts and the Michigan PDP region (13), not the local-MA STATE field. The coverage table checks actual records in each full component, rather than assuming all files include all selected plans. Formulary records without a price remain visible for investigation.''')
code('''table(json.loads((E/'plan_coverage.json').read_text()))
plans=query('SELECT contract_id,plan_id,segment_id,plan_name,premium,deductible,formulary_id,pdp_region_code FROM clean.plans ORDER BY contract_id,plan_id')
assert len(plans)==12
assert all(p['pdp_region_code']=='13' and p['contract_id'].startswith('S') for p in plans)
table(plans)''')
md('''## 4. Join examples

Plan → formulary uses formulary_id within the frozen year/quarter. Pricing additionally requires contract/plan/segment, NDC and days supply. Cost-sharing requires the same plan, tier, coverage phase and translated days supply. Examples below use initial coverage and 30 days to verify linkage, not to calculate annual costs. There may be multiple NDCs per clinical drug; those alternatives remain explicit. The full join has 22,850 priced combinations without initial cost-sharing records, all at 60/90 days. These are marked missing_cost_sharing, not estimated by borrowing a 30-day rate. All 30-day priced combinations have a matching initial cost-sharing row.''')
code('''examples=json.loads((E/'join_examples.json').read_text())
# One example per plan/product for readability; complete joined examples remain saved in evidence.
shown=[];seen=set()
for row in examples:
    key=(row['contract_id'],row['plan_id'],row['rxcui'])
    if key not in seen:
        seen.add(key);shown.append(row)
table(shown)
table([json.loads((E/'integration_summary.json').read_text())['join_examples']])
table(query("SELECT days_supply,input_status,count(*) AS records FROM clean.plan_drug_cost_inputs GROUP BY ALL ORDER BY days_supply,input_status"))''')
md('''## 5. Readable drug names and conservative matching

CMS codes are linked to NLM RxNorm product names by exact RXCUI. Full product names include strength/form and brand when present. The current NLM catalog version is saved separately from the historical CMS snapshot. Matching is identity lookup, not substitution advice.

Incomplete names return candidates. Missing entries are flagged. A unique RXCUI with several NDCs still needs a defined product selection; the system does not automatically use the cheapest code.''')
code('''print('NLM catalog version:',json.loads((ROOT/'data/reference/rxnorm_version.json').read_text()))
table(query('SELECT name_status,count(*) AS drug_concepts FROM clean.drug_catalog GROUP BY name_status'))
table(query("SELECT rxcui,name,tty FROM clean.drug_catalog WHERE contains(lower(name),'atorvastatin') ORDER BY name LIMIT 10"))
for value,kind in [('atorvastatin','name'),('atorvastatin 20 MG Oral Tablet','name'),('unknown-example-drug','name'),('123','ndc')]:
    result=match_medication(value,kind)
    print(value, '->', result['status'])
    if result.get('candidates'):table(result['candidates'][:5])''')
md('''## 6. Pharmacy network and directory demonstration

The complete CMS network subset supplies membership and preferred flags. A bounded NPPES lookup supplies current names/addresses for up to 20 specific Michigan locations. This is an intake demonstration, not a complete directory or a claim that current directory details equal Q3 historical details. Network status comes from CMS, not the directory.''')
code('''table(query('SELECT pharmacy_number,npi,name,address,city,state,source_network_zip FROM clean.pharmacy_directory ORDER BY name'))
table(query("SELECT p.plan_name,n.pharmacy_number,d.name,n.pharmacy_zipcode,n.pharmacy_retail,n.preferred_status_retail,n.pharmacy_mail,n.preferred_status_mail FROM clean.pharmacy_network n JOIN clean.plans p USING(contract_id,plan_id,segment_id) JOIN clean.pharmacy_directory d USING(pharmacy_number) ORDER BY n.pharmacy_number,p.plan_name LIMIT 24"))''')
md('''## 7. Intake requirements and remaining boundaries

- Required calculation inputs: exact medication product, quantity with unit, days supplied and fill schedule; plan and pharmacy selection.
- Michigan geography is fixed for the prototype. A beneficiary ZIP lookup is separate from pharmacy ZIP.
- Retail pharmacy flexibility and explanation preferences tailor the brief; they do not change medication identity.
- Preserve brand/generic, strength, formulation and route distinctions. Unknown/ambiguous selections require clarification.
- Average retail unit cost is not an exact pharmacy-specific quote or a validated mail-order price.
- Extra Help, income-based adjustments, annual benefit-phase simulation, special-drug rules and monthly budget feasibility need separate rules and validation. Data integration alone does not complete those calculations.
- Taylor's intake v2 is now connected in PlanWise_Intake_CMS_Connected.ipynb. It preserves the three tiers and produces 24 plan-linked records for two real drug products and a verified pharmacy. Twelve validation checks passed. Annual cost calculations remain future work.
- Two standup comments and review of team feedback remain pending the relevant posts/channel context. No comments have been posted from this artifact.

See `docs/INTAKE_AND_MATCHING.md` for the complete field-to-question mapping and `docs/DATA_DICTIONARY.md` for types and join rules.''')
nb=nbf.v4.new_notebook(cells=cells,metadata={'title':'Planwise: CMS Data Integration Review','kernelspec':{'display_name':'PlanWise (.venv)','language':'python','name':'planwise'}})
nbf.write(nb,R/'CMS_Data_Integration_Review.ipynb')
