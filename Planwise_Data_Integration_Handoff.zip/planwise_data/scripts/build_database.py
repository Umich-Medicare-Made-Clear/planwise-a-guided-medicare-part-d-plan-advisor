"""Build auditable Michigan PDP tables from all official Q3 2026 component ZIPs."""
from pathlib import Path
import zipfile,json,re,shutil,datetime
import duckdb
R=Path(__file__).resolve().parents[1]; RAW=R/'data/raw'; TMP=R/'data/staging';TMP.mkdir(exist_ok=True)
con=duckdb.connect(str(R/'data/planwise.duckdb'));con.execute("SET memory_limit='2GB'");con.execute('SET threads=4')
con.execute('CREATE SCHEMA IF NOT EXISTS raw');con.execute('CREATE SCHEMA IF NOT EXISTS clean')
keys=['contract_id','plan_id','segment_id']; audit=[]
def q(s):return '"'+s.replace('"','""')+'"'
def load(table,pattern,scope):
 files=sorted(RAW.glob(pattern));assert files,(table,'missing source')
 con.execute(f'DROP TABLE IF EXISTS raw.{table}')
 for p in files:
  with zipfile.ZipFile(p) as z:
   for info in z.infolist():
    if info.is_dir():continue
    dest=TMP/'current.txt'
    with z.open(info) as src,dest.open('wb') as out:shutil.copyfileobj(src,out,8*1024*1024)
    # CMS plan text contains Windows-1252 characters; normalize without altering originals.
    if table=='plans':
     dest.write_text(dest.read_bytes().decode('cp1252'),encoding='utf-8')
    header=dest.open(encoding='utf-8-sig').readline().strip().split('|')
    cols=[re.sub(r'[^a-z0-9_]+','_',c.strip().lower()) for c in header]
    assert len(cols)==len(set(cols))
    expr=', '.join(f"nullif(trim({q(old)}),'') AS {q(new)}" for old,new in zip(header,cols))
    source_sql="'"+str(dest).replace("'","''")+"'"
    con.execute(f"CREATE OR REPLACE TEMP VIEW source AS SELECT {expr} FROM read_csv({source_sql},delim='|',header=true,all_varchar=true,strict_mode=true)")
    n=con.execute('SELECT count(*) FROM source').fetchone()[0]
    exists=con.execute("SELECT count(*) FROM information_schema.tables WHERE table_schema='raw' AND table_name=?",[table]).fetchone()[0]
    sql=f'SELECT * FROM source {scope}'
    if exists:con.execute(f'INSERT INTO raw.{table} '+sql)
    else:con.execute(f'CREATE TABLE raw.{table} AS '+sql)
    audit.append(dict(table=table,archive=p.name,member=info.filename,source_rows=n,extracted_bytes=info.file_size))
    print(table,p.name,'source rows',n,flush=True)
    con.execute('DROP VIEW source');dest.unlink()
 # Deduplicate only identical business records, retaining conflict detection below.
 cols=[r[0] for r in con.execute(f'DESCRIBE raw.{table}').fetchall()]
 conversions={}
 for c in cols:
  if c in ['premium','deductible','unit_cost','floor_price'] or 'dispensing_fee' in c or c.startswith(('cost_amt','cost_min_amt','cost_max_amt','copay_amt','coin_amt')):conversions[c]='DECIMAL(18,6)'
  elif c in ['tier','tier_level_value','coverage_level','days_supply','in_area_flag','contract_year']:conversions[c]='INTEGER'
 markers={c:con.execute(f"SELECT count(*) FROM raw.{table} WHERE {q(c)}='.'").fetchone()[0] for c in conversions}
 errors={c:con.execute(f"SELECT count(*) FROM raw.{table} WHERE {q(c)} IS NOT NULL AND {q(c)}<>'.' AND try_cast({q(c)} AS {typ}) IS NULL").fetchone()[0] for c,typ in conversions.items()}
 if any(errors.values()): print('Numeric exceptions retained in raw:',table,errors,flush=True)
 expr=', '.join(f'try_cast({q(c)} AS {conversions[c]}) AS {q(c)}' if c in conversions else q(c) for c in cols)
 con.execute(f'CREATE OR REPLACE TABLE clean.{table} AS SELECT DISTINCT {expr} FROM raw.{table}')
 n=con.execute(f'SELECT count(*) FROM raw.{table}').fetchone()[0];d=con.execute(f'SELECT count(*) FROM (SELECT DISTINCT * FROM raw.{table})').fetchone()[0]
 missing=dict(zip(cols,con.execute(f'SELECT '+','.join(f'count(*) FILTER(WHERE {q(c)} IS NULL)' for c in cols)+f' FROM clean.{table}').fetchone()))
 stats[table]=dict(raw_scoped_rows=n,exact_duplicates=n-d,clean_rows=con.execute(f'SELECT count(*) FROM clean.{table}').fetchone()[0],null_counts=missing,numeric_conversion_failures=errors,numeric_missing_markers=markers,schema=[list(x[:2]) for x in con.execute(f'DESCRIBE clean.{table}').fetchall()])
 (R/'evidence/load_audit.json').write_text(json.dumps({'sources':audit,'tables':stats},indent=2))
stats={}
load('geography','geographic*.zip','')
load('plans','plan information*.zip',"WHERE contract_id LIKE 'S%' AND pdp_region_code IN (SELECT DISTINCT pdp_region_code FROM clean.geography WHERE upper(statename)='MICHIGAN')")
assert con.execute('SELECT count(*) FROM clean.plans').fetchone()[0]==12
load('formulary','basic drugs*.zip','WHERE formulary_id IN (SELECT formulary_id FROM clean.plans)')
plan_scope='WHERE (contract_id,plan_id,segment_id) IN (SELECT contract_id,plan_id,segment_id FROM clean.plans)'
for table,pat in [('cost_sharing','beneficiary cost*.zip'),('insulin_cost','insulin*.zip'),('pricing','pricing*.zip'),('pharmacy_network','pharmacy*.zip')]:load(table,pat,plan_scope)
for table,pat in [('excluded_drugs','excluded*.zip'),('indications','indication*.zip')]:load(table,pat,'WHERE (contract_id,plan_id) IN (SELECT contract_id,plan_id FROM clean.plans)')
con.execute('''CREATE OR REPLACE VIEW clean.cost_sharing_days AS SELECT *, CASE days_supply WHEN 1 THEN 30 WHEN 2 THEN 90 WHEN 4 THEN 60 END AS days_supply_days FROM clean.cost_sharing''')
con.execute('''CREATE OR REPLACE VIEW clean.plan_drug_prices AS
SELECT p.contract_id,p.plan_id,p.segment_id,p.plan_name,p.premium,p.deductible,p.formulary_id,
f.formulary_version,f.contract_year,f.rxcui,f.ndc,f.tier_level_value AS tier,
f.prior_authorization_yn,f.step_therapy_yn,f.quantity_limit_yn,f.quantity_limit_amount,f.quantity_limit_days,
r.days_supply,r.unit_cost
FROM clean.plans p JOIN clean.formulary f USING(formulary_id)
LEFT JOIN clean.pricing r ON p.contract_id=r.contract_id AND p.plan_id=r.plan_id AND p.segment_id=r.segment_id AND f.ndc=r.ndc''')
checks={}
for t,key in [('plans',keys),('formulary',['formulary_id','formulary_version','contract_year','ndc']),('pricing',keys+['ndc','days_supply']),('cost_sharing',keys+['coverage_level','tier','days_supply']),('pharmacy_network',keys+['pharmacy_number'])]:
 checks[t+'_duplicate_keys']=con.execute(f'SELECT count(*) FROM (SELECT {",".join(key)},count(*) n FROM clean.{t} GROUP BY ALL HAVING count(*)>1)').fetchone()[0]
 checks[t+'_missing_keys']=con.execute(f'SELECT count(*) FROM clean.{t} WHERE '+ ' OR '.join(q(k)+' IS NULL' for k in key)).fetchone()[0]
for c,width in [('plan_id',3),('segment_id',3),('formulary_id',8)]:checks[c+'_bad_width']=con.execute(f'SELECT count(*) FROM clean.plans WHERE length({c})<>{width}').fetchone()[0]
checks['ndc_bad_format']=con.execute("SELECT count(*) FROM clean.formulary WHERE NOT regexp_full_match(ndc,'[0-9]{11}')").fetchone()[0]
checks['contract_years']=[x[0] for x in con.execute('SELECT DISTINCT contract_year FROM clean.formulary').fetchall()]
checks['pricing_negative']=con.execute('SELECT count(*) FROM clean.pricing WHERE unit_cost<0').fetchone()[0]
checks['unmapped_cost_days_codes']=[x[0] for x in con.execute('SELECT DISTINCT days_supply FROM clean.cost_sharing_days WHERE days_supply_days IS NULL').fetchall()]
coverage=con.execute('''SELECT p.contract_id,p.plan_id,p.plan_name,
(SELECT count(*) FROM clean.formulary f WHERE f.formulary_id=p.formulary_id) formulary_rows,
(SELECT count(*) FROM clean.pricing r WHERE (r.contract_id,r.plan_id,r.segment_id)=(p.contract_id,p.plan_id,p.segment_id)) pricing_rows,
(SELECT count(*) FROM clean.pharmacy_network n WHERE (n.contract_id,n.plan_id,n.segment_id)=(p.contract_id,p.plan_id,p.segment_id)) network_rows,
(SELECT count(*) FROM clean.cost_sharing c WHERE (c.contract_id,c.plan_id,c.segment_id)=(p.contract_id,p.plan_id,p.segment_id)) cost_sharing_rows,
(SELECT count(*) FROM clean.formulary f WHERE f.formulary_id=p.formulary_id AND NOT EXISTS(SELECT 1 FROM clean.pricing r WHERE (r.contract_id,r.plan_id,r.segment_id)=(p.contract_id,p.plan_id,p.segment_id) AND r.ndc=f.ndc)) formulary_rows_without_price
FROM clean.plans p ORDER BY p.contract_id,p.plan_id''')
coverage=[dict(zip([x[0] for x in coverage.description],row)) for row in coverage.fetchall()]
(R/'evidence/quality_checks.json').write_text(json.dumps(checks,indent=2))
(R/'evidence/plan_coverage.json').write_text(json.dumps(coverage,indent=2))
con.close()
print(json.dumps(checks,indent=2),flush=True)
print('DATABASE READY',flush=True)
