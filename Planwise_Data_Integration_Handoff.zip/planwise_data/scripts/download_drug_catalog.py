from pathlib import Path
import requests,json,datetime,hashlib
R=Path(__file__).resolve().parents[1]; out=R/'data/reference';out.mkdir(exist_ok=True)
urls={'rxnorm_products':'https://rxnav.nlm.nih.gov/REST/allconcepts.json?tty=SCD+SBD+GPCK+BPCK','rxnorm_version':'https://rxnav.nlm.nih.gov/REST/version.json'}
manifest=[]
for name,url in urls.items():
 response=requests.get(url,timeout=180);response.raise_for_status();payload=response.content
 json.loads(payload);(out/(name+'.json')).write_bytes(payload)
 manifest.append(dict(file=name+'.json',url=url,retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest()))
 print(name,len(payload),flush=True)
(R/'evidence/reference_manifest.json').write_text(json.dumps(manifest,indent=2))
