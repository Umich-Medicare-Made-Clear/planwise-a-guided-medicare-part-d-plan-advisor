"""Connect Taylor's tiered intake to the prepared CMS database."""
from pathlib import Path
import json,math,datetime
import duckdb
R=Path(__file__).resolve().parents[1];DB=R/'data/planwise.duckdb'

def records(sql,params=None):
    with duckdb.connect(str(DB),read_only=True) as con:
        cur=con.execute(sql,params or [])
        return [dict(zip([x[0] for x in cur.description],row)) for row in cur.fetchall()]

def load_catalogs():
    meds=records("SELECT rxcui,name AS display_name,tty FROM clean.drug_catalog WHERE name_status='mapped' ORDER BY name")
    pharmacies=records("SELECT pharmacy_number AS location_id,pharmacy_number,npi,name AS organization_name,address,city,state,substr(postal_code,1,5) AS zip_code,source_network_zip FROM clean.pharmacy_directory WHERE nppes_status='A' ORDER BY name,address")
    for p in pharmacies:p['location_name']=f"{p['organization_name']} — {p['address']}, {p['city']}, {p['state']} {p['zip_code']}"
    return meds,pharmacies

def medication_details(rxcui,allow_network=False):
    if not records('SELECT rxcui FROM clean.drug_catalog WHERE rxcui=?',[str(rxcui)]):raise ValueError('RXCUI is not in the Michigan formulary catalog.')
    p=R/'data/reference/rxterms'/(str(rxcui)+'.json')
    if not p.exists():
        if not allow_network:raise ValueError('Structured strength/form not cached. Fetch RxTerms details explicitly with allow_network=True; do not guess from the name.')
        import requests
        url=f'https://rxnav.nlm.nih.gov/REST/RxTerms/rxcui/{rxcui}/allinfo.json'
        response=requests.get(url,timeout=30);response.raise_for_status();payload=response.json()
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(json.dumps({'source_url':url,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'payload':payload},indent=2))
    data=json.loads(p.read_text())['payload'].get('rxtermsProperties',{})
    if str(data.get('rxcui'))!=str(rxcui) or not data.get('strength') or not data.get('rxnormDoseForm'):
        raise ValueError('Structured strength/form is unavailable; clarify the medication rather than inventing values.')
    if data.get('suppress') not in ('',None,'N'):raise ValueError('RxTerms product is suppressed; review before selection.')
    return data

def ndc_choices(rxcui):
    return [r['ndc'] for r in records('SELECT DISTINCT ndc FROM clean.formulary WHERE rxcui=? ORDER BY ndc',[str(rxcui)])]

def valid_quantity_and_days(quantity,days_supply):
    try:
        if isinstance(quantity,bool) or isinstance(days_supply,bool):return False
        q=float(quantity);d=float(days_supply)
        return math.isfinite(q) and math.isfinite(d) and q>0 and d>0 and d.is_integer()
    except (TypeError,ValueError,OverflowError):return False

def select_medication(rxcui,quantity_per_fill,days_supply,ndc=None,assume_year_round_use=True,allow_network=False):
    if not valid_quantity_and_days(quantity_per_fill,days_supply):raise ValueError('Quantity must be finite and positive; days supply must be a positive whole number.')
    if int(days_supply) not in (30,60,90):raise ValueError('This prototype currently maps 30, 60 or 90 days only.')
    if not isinstance(assume_year_round_use,bool):raise ValueError('Year-round-use assumption must be True or False.')
    drug=records('SELECT rxcui,name,tty FROM clean.drug_catalog WHERE rxcui=?',[str(rxcui)])
    if len(drug)!=1:raise ValueError('Select a specific RXCUI from the catalog.')
    options=ndc_choices(rxcui)
    if ndc is None:
        if len(options)!=1:raise ValueError('Multiple NDCs require explicit product selection: '+', '.join(options))
        ndc=options[0]
    if ndc not in options:raise ValueError('NDC does not belong to the selected CMS medication.')
    info=medication_details(rxcui,allow_network)
    return {'medication_name':drug[0]['name'],'rxcui':str(rxcui),'ndc':ndc,'strength':info['strength'],'dosage_form':info['rxnormDoseForm'],'quantity_per_fill':float(quantity_per_fill),'days_supply':int(days_supply),'assume_year_round_use':assume_year_round_use}

def validate_selected_medications(medications):
    errors=[]
    for i,med in enumerate(medications,1):
        if not isinstance(med,dict):errors.append(f'Medication {i} must be a record.');continue
        try:
            expected=select_medication(med.get('rxcui'),med.get('quantity_per_fill'),med.get('days_supply'),med.get('ndc'),med.get('assume_year_round_use'))
            for field in ['medication_name','strength','dosage_form','ndc']:
                if med.get(field)!=expected[field]:errors.append(f'Medication {i}: {field} does not match the selected catalog record.')
        except ValueError as exc:errors.append(f'Medication {i}: {exc}')
    return errors

def validate_pharmacy(pharmacy):
    if not isinstance(pharmacy,dict):return ['Select a pharmacy record.']
    _,options=load_catalogs();matched=[p for p in options if p['location_id']==pharmacy.get('location_id')]
    if not matched:return ['Pharmacy location is not in the connected demo directory.']
    if any(pharmacy.get(k)!=matched[0][k] for k in ['pharmacy_number','npi','location_name','zip_code']):return ['Pharmacy identifiers and label do not match the directory.']
    return []

def plan_input_preview(intake):
    """Plan-by-medication linkage; never ranks plans or calculates annual costs."""
    t=intake['tier1']
    if t['extra_help_status']!='No':return []
    result=[]
    for med in t['medications']:
        rows=records('''SELECT p.contract_id,p.plan_id,p.plan_name,p.premium,p.deductible,
        d.rxcui,d.ndc,d.drug_name,d.tier,d.days_supply,d.unit_cost,d.cost_type_pref,d.cost_amt_pref,d.cost_type_nonpref,d.cost_amt_nonpref,
        d.prior_authorization_yn,d.step_therapy_yn,d.quantity_limit_yn,
        n.pharmacy_number,n.preferred_status_retail,
        CASE WHEN n.pharmacy_number IS NULL THEN 'pharmacy_not_in_network'
             WHEN n.pharmacy_retail<>'Y' THEN 'retail_channel_not_supported'
             WHEN d.ndc IS NULL THEN 'drug_or_supply_not_available'
             ELSE d.input_status END AS data_status
        FROM clean.plans p LEFT JOIN clean.plan_drug_cost_inputs d
          ON p.contract_id=d.contract_id AND p.plan_id=d.plan_id AND p.segment_id=d.segment_id AND d.rxcui=? AND d.ndc=? AND d.days_supply=?
        LEFT JOIN clean.pharmacy_network n
          ON p.contract_id=n.contract_id AND p.plan_id=n.plan_id AND p.segment_id=n.segment_id AND n.pharmacy_number=?
        ORDER BY p.contract_id,p.plan_id''',[med['rxcui'],med['ndc'],med['days_supply'],t['pharmacy_location']['pharmacy_number']])
        for row in rows:
            row['requested_medication']=med['medication_name'];row['quantity_per_fill']=med['quantity_per_fill']
        result.extend(rows)
    return result
