from pathlib import Path
import json,duckdb,sys
R=Path(__file__).resolve().parents[1]
con=duckdb.connect(str(R/'data/planwise.duckdb'))
products=json.loads((R/'data/reference/rxnorm_products.json').read_text())['minConceptGroup']['minConcept']
con.execute('CREATE OR REPLACE TEMP TABLE nlm(rxcui VARCHAR,name VARCHAR,tty VARCHAR)')
con.executemany('INSERT INTO nlm VALUES (?,?,?)',[(x['rxcui'],x['name'],x['tty']) for x in products])
con.execute('''CREATE OR REPLACE TABLE clean.drug_catalog AS SELECT DISTINCT f.rxcui,n.name,n.tty,CASE WHEN n.name IS NULL THEN 'name_unresolved' ELSE 'mapped' END name_status FROM clean.formulary f LEFT JOIN nlm n USING(rxcui)''')
con.execute('''CREATE OR REPLACE VIEW clean.named_plan_drugs AS SELECT d.*,n.name AS drug_name,n.tty FROM clean.plan_drug_prices d LEFT JOIN clean.drug_catalog n USING(rxcui)''')
# Link pharmacy numbers to NPIs only for the documented 12-digit 10-prefix representation.
con.execute('''CREATE OR REPLACE VIEW clean.pharmacies AS SELECT DISTINCT pharmacy_number,pharmacy_zipcode,CASE WHEN regexp_full_match(pharmacy_number,'10[0-9]{10}') THEN substr(pharmacy_number,3) END npi FROM clean.pharmacy_network''')
name_summary=dict(con.execute("SELECT name_status,count(*) FROM clean.drug_catalog GROUP BY name_status").fetchall())
summary={'drug_names':name_summary,'unique_pharmacy_numbers':con.execute('SELECT count(DISTINCT pharmacy_number) FROM clean.pharmacies').fetchone()[0],'pharmacy_numbers_without_derived_npi':con.execute('SELECT count(DISTINCT pharmacy_number) FROM clean.pharmacies WHERE npi IS NULL').fetchone()[0]}
# Explicitly select three distinct clinical products for cross-plan join checks.
names=['atorvastatin 20 MG Oral Tablet','metformin hydrochloride 500 MG Oral Tablet','lisinopril 10 MG Oral Tablet']
rx=[]
for name in names:
 rows=con.execute('SELECT rxcui,name FROM clean.drug_catalog WHERE lower(name)=lower(?)',[name]).fetchall()
 if rows:rx.append(rows[0][0])
if len(rx)<3:
 for row in con.execute("SELECT rxcui FROM clean.drug_catalog WHERE tty='SCD' AND name IS NOT NULL ORDER BY name LIMIT 10").fetchall():
  if row[0] not in rx:rx.append(row[0])
  if len(rx)==3:break
query='''SELECT d.contract_id,d.plan_id,d.segment_id,d.plan_name,d.drug_name,d.rxcui,d.ndc,d.tier,d.days_supply,d.unit_cost,d.premium,d.deductible,d.prior_authorization_yn,d.step_therapy_yn,d.quantity_limit_yn,c.coverage_level,c.cost_type_pref,c.cost_amt_pref,c.cost_type_nonpref,c.cost_amt_nonpref,c.ded_applies_yn
FROM clean.named_plan_drugs d LEFT JOIN clean.cost_sharing_days c
ON d.contract_id=c.contract_id AND d.plan_id=c.plan_id AND d.segment_id=c.segment_id AND d.tier=c.tier AND d.days_supply=c.days_supply_days AND c.coverage_level=1
WHERE d.rxcui IN ('''+','.join('?' for _ in rx)+''') AND d.days_supply=30 ORDER BY d.contract_id,d.plan_id,d.rxcui,d.ndc'''
cur=con.execute(query,rx);headers=[x[0] for x in cur.description];samples=[dict(zip(headers,r)) for r in cur.fetchall()]
assert samples,'No joined sample drugs'
assert len({x['rxcui'] for x in samples})==3
summary['join_examples']={'records':len(samples),'distinct_plans':len({(x['contract_id'],x['plan_id'],x['segment_id']) for x in samples}),'distinct_drugs':len({x['rxcui'] for x in samples}),'missing_initial_cost_share':sum(x['coverage_level'] is None for x in samples)}
(R/'evidence/join_examples.json').write_text(json.dumps(samples,indent=2,default=str))
# A formulary code must have the same source drug identity after the join.
assert all(x['drug_name'] and x['ndc'] and len(x['ndc'])==11 for x in samples)
con.close()
from lookup import match_medication
cases={'empty':match_medication(''),'unknown':match_medication('not-a-real-medication-xyz'),'ambiguous':match_medication('atorvastatin'),'exact_ndc':match_medication(samples[0]['ndc'],'ndc'),'invalid_ndc':match_medication('123','ndc'),'exact_name':match_medication(samples[0]['drug_name'])}
assert cases['empty']['status']=='unmatched'
assert cases['unknown']['status']=='unmatched'
assert cases['ambiguous']['status']=='needs_clarification'
assert cases['invalid_ndc']['status']=='needs_clarification'
assert cases['exact_ndc']['status']=='matched'
(R/'evidence/matching_tests.json').write_text(json.dumps(cases,indent=2))
summary['matching_tests']='Passed empty, unknown, partial/ambiguous, invalid NDC, exact NDC, and exact full-name examples.'
(R/'evidence/integration_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
