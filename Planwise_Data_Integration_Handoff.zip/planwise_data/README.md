# Planwise: CMS Data Integration

Rechelle Transeth — November 7, 2026

## Start here

Open **CMS_Data_Integration_Review.html** for a readable report with scrollable tables and saved results. Open **CMS_Data_Integration_Review.ipynb** in VS Code to inspect and rerun the queries. This is a new integration artifact; the earlier `rechelle_week1` files remain intact.

## Checklist status

| Assigned work | Status | Evidence |
|---|---|---|
| Finalize required 2026 CMS datasets | Complete for Q3 Michigan PDP scope | All 14 full component ZIPs downloaded, including pricing and all six pharmacy parts. Manifest records filenames, sources, year, sizes, checksums and retrieval dates. |
| Confirm Michigan coverage | Complete at table/plan level | All 12 plans have formulary, price, network and cost-sharing records. Detailed record-level gaps are reported separately. |
| Identify key fields and missing/inconsistent data | Complete | Data dictionary, schema/null/type audit, restrictions, pharmacy flags, missing selected-drug fees, days-supply mapping. |
| Clean and load data into DuckDB | Complete | Nine raw and clean source tables; normalized columns, preserved IDs, typed numeric values, checks for exact duplicates and conflicting keys. |
| Connect plans, formulary and pricing | Complete | Saved joined views; three medication products tested across all 12 plans. Cost-sharing matching and row-multiplication checks included. |
| Map fields to intake/recommendation requirements | Complete | `docs/INTAKE_AND_MATCHING.md` maps each input to fields, use and limitations. |
| Define medication standardization and matching | Complete with tested lookup implementation | All 4,261 Michigan RXCUIs matched to NLM names. Exact/ambiguous/unmatched cases tested. Brand, strength and form remain distinct; multiple NDCs require selection. |
| Post two standup comments | Pending | Relevant posts/channel context not supplied. Draft progress updates are provided; nothing has been posted. |
| Read team questions/feedback | Pending | No connected Slack/Drive access or supplied recent feedback. |

Taylor's supplied intake v2 is now connected in `PlanWise_Intake_CMS_Connected.ipynb`. Its original question tiers are retained. The example uses two real medications and one verified pharmacy and joins both medications across all 12 plans. Twelve validation checks passed. The untouched original is in `reference/Taylor_Intake_v2_original.ipynb`.

## Verified results

- 14 complete CMS component ZIPs, 2,515,581,660 compressed bytes.
- 362,161,483 source rows scanned across components (different table grains; not a person or plan count).
- 12 Michigan plans; 35,441 distinct formulary rows across the selected formulary IDs.
- 100,111 plan-drug-days-supply pricing rows.
- 667,631 plan-pharmacy network rows, representing 62,371 distinct pharmacy numbers across the selected plans' networks. These include out-of-state network locations; they are not 62,371 Michigan storefronts.
- 330 beneficiary-cost rows; 88 insulin-cost rows; 18 supplemental excluded-drug rows; no indication-based coverage rows for this selected scope.
- No exact duplicates or conflicting logical keys detected in the audited grains. No missing core keys or malformed audited ID widths. No negative unit prices.
- All 4,261 distinct Michigan formulary RXCUIs have current NLM product names.
- 20 current Michigan NPPES directory locations linked by NPI as a bounded intake demonstration, not a complete historical directory.
- Three distinct medication products joined across all 12 plans (36 example rows) with initial-coverage 30-day cost sharing. All 30-day priced combinations have matching initial cost-sharing rows.

## Material data limitations

**Longer supplies:** 22,850 priced plan-drug-days-supply combinations have no matching initial-coverage cost-sharing row, all for 60/90 days. The view flags these `missing_cost_sharing`. Do not infer coverage or reuse a 30-day cost-sharing rate. A missing row may reflect an unsupported supply/tier combination; further benefit interpretation is needed.

**Missing fees:** For each of the three selected-drug dispensing-fee columns, 286,417 scoped network rows contain `.`. Raw values remain intact; clean values are NULL. These are recorded as missing markers, not zeros. There are no other numeric parse failures after accounting for those markers.

**Cost engine boundary:** Joining costs and tiers does not complete annual benefit-phase simulation, insulin/selected-drug rules, deductible progression, out-of-pocket accumulation, Extra Help or monthly-budget modeling. Annual cost estimates are not produced or claimed validated here. Retail unit costs are averages, not exact quotes for each pharmacy. No mail-order pricing equivalence is assumed.

**Source timing:** CMS is a frozen Q3 2026 snapshot. RxNorm and NPPES are current lookups retrieved for this work; version/timestamps are saved. Current directory labels do not independently prove historical participation. CMS network records establish the snapshot membership.

## Reproduce

On this Mac, from `planwise_data`, the existing environment is `../rechelle_week1/.venv/bin/python`. For another machine, create a Python 3.12 virtual environment and install `requirements.txt`.

To validate the provided prepared database offline:

```sh
python scripts/test_lookups.py
python scripts/final_checks.py
```

Or open the notebook, select that Python environment and click Run All. Its queries are read-only. The automated validation commands save updated evidence and the final status view.

To rebuild from source:

```sh
python scripts/download_full.py
python scripts/download_drug_catalog.py
python scripts/build_database.py
python scripts/enrich_and_validate.py
python scripts/pharmacy_directory.py
python scripts/final_checks.py
python scripts/test_lookups.py
```

The first two download commands and pharmacy-directory lookup require internet. Full extraction uses one temporary text file at a time, about 4 GB maximum. Cached downloads are retained. `download_full.py` reads the copied selected-release metadata in this folder (and reuses previous Week 1 ZIPs if available).

Example intake lookup:

```python
import sys
sys.path.insert(0, 'scripts')
from lookup import match_medication
result = match_medication('atorvastatin')
# needs_clarification: offer exact strength/form selections
```

For a selected NDC, call `match_medication(ndc, kind='ndc')`. See `docs/INTAKE_AND_MATCHING.md` for the returned structure. Search is deterministic exact/substring matching, not a free-text medication parser or clinical substitution system.

## Sharing

The review HTML and executed notebook contain results for discussion. The handoff ZIP includes the prepared database, cached lookups, scripts, evidence, and documentation; it excludes the 2.5 GB original ZIP downloads and the Python environment. Originals remain locally available and can be downloaded again from the manifest. Do not upload the database or raw datasets to Git by default; `.gitignore` excludes `data/`. The CMS Agreement for Use still applies to source material.

## Connected intake notebook

Open `PlanWise_Intake_CMS_Connected.html` for the saved intake demonstration or `PlanWise_Intake_CMS_Connected.ipynb` to Run All. It uses `scripts/intake_data.py` as an adapter between Taylor's original field names and the database.

The full name-search list contains 4,261 medication concepts. Structured strength/form details for the two demo products are cached from NLM RxTerms. Other selections may need an explicit call to `medication_details(rxcui, allow_network=True)` before `select_medication`. This is not a claim that every possible product has been tested. The directory contains 20 locations, not all Michigan pharmacies.

The integration strengthens positive-number checks to reject infinity, booleans and fractional days, checks drug/RXCUI/NDC/strength/form consistency, checks pharmacy identity, and preserves all tiered preferences. The synthetic example uses Michigan ZIP 48001. A five-digit ZIP-format check by itself still does not verify Michigan residency; no ZIP-to-state crosswalk has been added. Annual costs and recommendations are not calculated.
