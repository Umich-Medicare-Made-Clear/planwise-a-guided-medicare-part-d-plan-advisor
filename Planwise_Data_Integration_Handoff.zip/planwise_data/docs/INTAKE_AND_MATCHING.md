# Intake requirements and medication matching

Scope: Michigan stand-alone PDPs, 2026 Q3 source snapshot. This document defines the data interface. Taylor's intake v2 is connected through `scripts/intake_data.py` in `PlanWise_Intake_CMS_Connected.ipynb`.

## Intake-to-data mapping

| Input or requirement | Data fields | Use and limitation |
|---|---|---|
| Michigan residence | geography.statename / pdp_region_code; plans.contract_id | Match Michigan region, select S contracts. User ZIP requires a separate geography crosswalk; pharmacy ZIP is not residence. |
| Medication selection | drug_catalog.rxcui / name / tty; formulary.rxcui / ndc | Return stable identifier and complete name containing strength/form. Free-text candidates require explicit selection. |
| Brand vs generic | RxNorm SBD/BPCK vs SCD/GPCK | Preserve requested product. No automatic brand-to-generic or therapeutic substitution. |
| Quantity per fill | User-provided quantity and unit | Needed for unit-cost estimate; cannot infer quantity from drug strength. Tablets, mL, inhaler packages and packs need compatible units. Complex quantities remain unsupported until validated. |
| Days supplied | pricing.days_supply; cost_sharing_days.days_supply_days | Cost-sharing code 1=30, 2=90, 4=60; code 3 means other and remains unmapped rather than being guessed. |
| Planned fills / duration | Explicit profile fill schedule | Annual costs require schedule and benefit phase rules; do not infer full-year treatment without an assumption. |
| Specific pharmacy | pharmacy_network.pharmacy_number, pharmacy_zipcode, preferred_status_retail/mail, pharmacy_retail/mail | Presence in the plan's network and status. NPPES names/addresses are a supplemental current lookup, not proof of historical participation. |
| Alternative pharmacy preference | Profile boolean/unknown | Explanation/selection constraint. Retail unit prices are averages, not exact pharmacy-specific quotes. |
| Premium preference | plans.premium | Explain monthly premium and annual premium (12 × monthly premium for a full year), separately from drug costs. |
| Deductible | plans.deductible; cost_sharing.ded_applies_yn | Annual deductible and tier applicability. A premium/price join is not a complete annual cost engine. |
| Drug restrictions | formulary.prior_authorization_yn / step_therapy_yn / quantity_limit_*; indications.disease | Display restrictions, not approval predictions. Indication-specific coverage and supplemental excluded drugs require separate interpretation. |
| Copay / coinsurance | cost_sharing.coverage_level / tier / cost_type_* / cost_amt_* / min/max | Interpret amount based on type: 1=copay, 2=coinsurance, 0=not offered. Never apply a dollar interpretation to all amounts. |
| Insulin | insulin_cost copay/coinsurance fields | Special rules need integration and validation before member-cost estimates. |
| Extra Help | Not supplied by the ordinary beneficiary-cost table | This table describes an unsubsidized beneficiary. Eligibility and subsidized calculations require additional inputs/rules. Initial numerical scope excludes Extra Help. |
| Predictable monthly costs | No direct field | Requires an explicit fill schedule and phase simulation; do not infer from premium alone. |

## Matching contract

1. Preserve source RXCUI/NDC strings. Keep NDC at 11 digits; never truncate or guess padding for an unknown 10-digit NDC pattern. Leading zeros in plan/segment/formulary identifiers remain intact.
2. Prefer an exact selected RXCUI or NDC, restricted to records in the Michigan formulary union. Exact identifiers establish identity, not coverage under every plan.
3. Offer case-insensitive medication-name search over the cached NLM names. The full normalized name includes strength, form and brand when applicable. Keep separate strengths, release forms and routes distinct.
4. Exact full-name match is accepted only when unique. Partial, misspelled or brand-only names return suggestions and status `needs_clarification`; they are never silently accepted. Empty or unknown entries return `unmatched`.
5. Selection of an RXCUI can correspond to multiple CMS NDCs. Preserve every candidate and return `needs_ndc_selection` if pricing depends on which is chosen. Do not quietly take the cheapest product.
6. If a CMS RXCUI is absent from the current NLM product catalog, retain it with status `name_unresolved`. A current catalog and Q3 snapshot can differ. Historical/remapped identifiers require an explicit reviewed mapping; never silently replace the source code.
7. No LLM is required for this lookup workflow. If free-text parsing is later added, it may propose candidates but cannot invent identifiers or make clinical substitution decisions.

## Interface returned to the intake notebook

A medication result contains `status`, `candidates` (RXCUI, full name, term type), and where applicable `ndc_candidates`. A pharmacy selection should contain the original `pharmacy_number`, NPI when valid, and a verified location label. User inputs supply quantity, unit, days_supply and fill schedule separately.

The connected notebook retains Taylor's tier1/tier2/tier3 record structure, populates medication and pharmacy selections, validates identifiers, and produces plan-linked inputs. It does not yet generate annual costs or a recommendation. Structured RxTerms details are cached for the two demo products, with explicit on-demand retrieval available for others.

## Sources

- CMS layout: https://data.cms.gov/sites/default/files/2025-10/83da019f-fa24-483e-87de-cc089780a6a5/SPUFRecordLayout-2026.pdf
- NLM product catalog: https://lhncbc.nlm.nih.gov/RxNav/APIs/api-RxNorm.getAllConceptsByTTY.html
- NLM historical identifiers: https://lhncbc.nlm.nih.gov/RxNav/APIs/api-RxNorm.getRxcuiHistoryStatus.html
- NPPES directory API: https://npiregistry.cms.hhs.gov/api-page
