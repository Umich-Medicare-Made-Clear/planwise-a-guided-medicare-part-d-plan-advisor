# Data model and join rules

All operational tables use schema `clean`; whitespace-trimmed Michigan source rows use `raw`. Original component ZIPs remain in `data/raw`. `clean.geography` retains all geographic rows so the Michigan region selection is reproducible. Other tables are scoped to the selected Michigan PDPs or their formularies.

## Required sources

- Plan information: plan IDs/names, formulary link, premium, deductible, region, suppression flag.
- Geographic locator: Michigan PDP region selection, SSA county codes (not FIPS).
- Basic drugs formulary: RXCUI/NDC, tier, quantity limits, prior authorization, step therapy, selected-drug indicator.
- Pricing: plan/segment/NDC/days-supply retail average unit costs.
- Beneficiary cost: coverage phase/tier/days-supply/channel cost-sharing amounts and types.
- Pharmacy networks, all six parts: plan/segment/pharmacy identifiers, ZIP, network channel, preferred flags, fees/floor prices.
- Insulin cost: separate insulin copay/coinsurance fields.
- Excluded drugs: supplemental coverage that must not be confused with ordinary Part D formulary coverage.
- Indication-based formulary: coverage conditional on indication, requiring additional logic for a complete cost engine.
- NLM RxNorm current product catalog: supplementary medication names including strength/form and term type. Retrieval version is saved; this is a current name lookup applied to a Q3 historical snapshot.

The exact ZIP names, URLs, benefit year, quarter, sizes, timestamps and SHA-256 hashes are saved in `evidence/download_manifest.json`. Source-member text sizes and nationwide row counts are in `load_audit.json`. This work intentionally uses the proposal's Q3 2026 release rather than switching to a newer benefit-year release.

## Types and cleaning

- Column names: lowercase snake_case; trim whitespace; empty strings become NULL.
- Preserve identifiers as text. Plan and segment IDs are three characters, formulary IDs eight, NDC eleven. RXCUI is a concept identifier, not a quantity. No blanket zero-padding/truncation or lossy numerical conversion.
- Monetary amounts and rates: DECIMAL(18,6). Their semantic interpretation still depends on the cost-type code.
- Tier, coverage phase, days supply, contract year and in-area flag: INTEGER.
- Y/N fields remain explicit source codes; do not silently map unexpected flags to false.
- Separate source rows and cleaned rows. Remove exact duplicates only; report duplicate logical keys separately. Conflicting duplicate keys require review, not choosing a row arbitrarily.
- Strict pipe-delimited parser. Plan text is decoded from Windows-1252; other inspected data is UTF-8. Preserve all original ZIP bytes.
- Numeric parse failures are counted and remain available as original text in `raw`; clean NULLs must never become zero estimates. The observed period (`.`) in selected-drug dispensing fees is explicitly recorded as a missing-value marker (286,417 occurrences per column), not a numeric zero.
- Source headers `selected_dispensing_fee_*` differ from the CMS PDF's `selected_drug_dispensing_fee_*`; the database uses actual observed headers.

## Join grains

| Table | Expected key / grain |
|---|---|
| plans | contract_id + plan_id + segment_id within the frozen year/quarter |
| formulary | formulary_id + formulary_version + contract_year + ndc; audit potential multiple RxCUIs per key |
| pricing | contract_id + plan_id + segment_id + ndc + days_supply |
| cost_sharing | contract_id + plan_id + segment_id + coverage_level + tier + days_supply code |
| pharmacy_network | contract_id + plan_id + segment_id + pharmacy_number; duplicate/conflicting entries audited |
| insulin_cost | contract_id + plan_id + segment_id + tier + days_supply; tier may be absent for defined-standard plans |
| indications | contract_id + plan_id + rxcui + disease |
| excluded_drugs | contract_id + plan_id + rxcui plus any supplemental benefit distinctions |

Plan-to-formulary joins use formulary_id inside this single-quarter, single-year snapshot. Multi-year databases must add source year/quarter and handle formulary versions deliberately. Drug pricing joins use plan/segment plus NDC, retaining days supply. Restriction flags come from the exact formulary record, not an unrelated name match.

Cost sharing joins require plan/segment, coverage phase, tier and mapped days supply. The basic formulary calls the tier `tier_level_value`; the joined view exposes `tier`. The examples use initial coverage (1) and 30 days solely to test the join. They are not annual member-cost estimates.

The pricing join is LEFT JOIN so missing prices remain visible. A missing price is unknown, never zero. Network joins should select a pharmacy before joining to avoid multiplying each medication row by every pharmacy in the network.

## Validation artifacts

- `load_audit.json`: all source row counts, selected/clean row counts, null counts, numeric parse failures, exact duplicates and schemas.
- `quality_checks.json`: logical key checks, identifier format checks, plan year and unsupported days-supply codes.
- `plan_coverage.json`: all 12 plans and their formulary, pricing, network and cost-sharing row counts; absent prices reported.
- `join_examples.json`: several medication products across Michigan plans, including source identifiers, prices, tiers and restrictions.
- `matching_tests.json`: exact matches and clarification/unmatched behavior.

An empty indication or excluded-drug subset may be valid. A missing core pricing/network/cost-sharing dataset is not silently accepted as a zero-cost plan.
