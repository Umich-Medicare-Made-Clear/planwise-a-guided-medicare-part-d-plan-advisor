# Draft progress updates — not posted

These are project updates, not responses to classmates' videos. If the course requires two comments on other groups' standups, review those posts and write responses to their actual work instead. The channel/posts and team feedback have not been supplied.

## Update 1

I completed the full Q3 2026 CMS downloads and loaded cleaned data for our 12 Michigan Part D plans into DuckDB. All 12 have formulary, pricing, pharmacy-network and cost-sharing records. I also linked all 4,261 medication concepts in the Michigan formularies to readable RxNorm names and documented the fields needed by the intake.

## Update 2

The plan–drug–price–cost-sharing joins are tested for three medications across all 12 plans, and the lookup flags ambiguous or unmatched medication entries. One important limitation: some 60/90-day pricing rows have no matching initial cost-sharing record, so those combinations are flagged rather than estimated. The data module is ready for connection to the intake notebook; annual cost calculations still need implementation and validation.
