# Cost calculation review

Rechelle Transeth · November 22, 2026

## What was checked

Three cases use the prepared CMS database for Wellcare Classic (contract S4802, plan 084, segment 000). Expected amounts were calculated separately from the engine's payment and ledger functions. Source prices, fees, floor price, deductible applicability and plan premium were read directly from the database. This checks agreement with separately worked arithmetic under the existing modeling assumptions; it is not independent validation of those assumptions or a Plan Finder comparison.

| Case | Separately worked calculation | Expected annual total | Engine total | Result |
|---|---|---:|---:|---|
| One drug, 30 days | Atorvastatin: 30 × $0.1476 = $4.428, rounded to $4.43 per purchase; 13 × $4.43 | $57.59 | $57.59 | Pass |
| Two drugs, 30 days | Lisinopril: 30 × $0.073 = $2.19; 13 × ($4.43 + $2.19) | $86.06 | $86.06 | Pass |
| Two drugs, 90 days | Atorvastatin: 90 × $0.1736 = $15.624 → $15.62; lisinopril: 90 × $0.0772 = $6.948 → $6.95; 5 × ($15.62 + $6.95) | $112.85 | $112.85 | Pass |

For these records the monthly premium, dispensing fees and floor price are zero. The shared plan deductible is $615 and applies to both medications. Total modeled drug spending remains below it, so the member pays the modeled prescription prices. These cases do not test what happens after that deductible is exhausted. The 90-day unit prices differ from the 30-day unit prices; the engine does not multiply a 30-day price by three.

The schedule assumes full purchases beginning January 1: 13 purchases at 30-day intervals or five at 90-day intervals. Some purchased supply carries into the next year. This is not exactly 365 days of consumed medication or one purchase per calendar month.

## Additional shared-deductible boundary check

A deliberately hypothetical test case uses two $10 prescriptions filled 13 times each, one shared $15 deductible, 25% coinsurance afterward, and $10 monthly premiums.

- Gross drug cost: 2 × 13 × $10 = $260.
- Medication expense: $15 + 25% × ($260 − $15) = $76.25.
- Annual premiums: 12 × $10 = $120.
- Expected annual total: $196.25. Engine total: $196.25. **Pass.**

The engine also reported exactly $15 paid toward the deductible. This checks one shared deductible rather than one per medication and adds a nonzero-premium example. It is an arithmetic test case, not a real plan or proof that a specific plan uses these rules.

## Conclusions and limits

All four checks matched; no arithmetic discrepancy was found in these cases. They reuse the same data snapshot and were prepared alongside the software, so they are not an external audit. The three connected cases cover one plan and two products, not all plans or medications.

Still unverified: the prescription-price construction, fixed-copay treatment on a fill that crosses the deductible, other payment-rule interpretations, and agreement with Medicare Plan Finder. Higher-spending annual coverage rules remain unimplemented. Unsupported products and missing 60-/90-day rules remain flagged. No additional medication products were enabled in this review.

Detailed inputs and results are saved in `handoff/calculation_checks.json`; `scripts/prepare_cost_handoff.py` reproduces the checks. A pass requires matching expected annual amounts and deductible payments, not merely a successful program run.
