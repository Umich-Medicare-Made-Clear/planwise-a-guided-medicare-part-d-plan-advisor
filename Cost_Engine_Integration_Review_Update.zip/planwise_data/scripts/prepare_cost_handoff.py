"""Create versioned integration examples and separate arithmetic checks."""
import json
from copy import deepcopy
from decimal import Decimal as D, ROUND_HALF_UP
from pathlib import Path
import duckdb
from cost_engine import ROOT, compare_plans, simulate, json_default

OUT=ROOT/'handoff'
OUT.mkdir(exist_ok=True)
def save(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2,default=json_default)+'\n')
base=json.loads((ROOT/'evidence/integrated_intake_example.json').read_text())
base.pop('scope_checks',None) # obsolete intake-stage commentary is not an engine input
save('input_success.json',base)
good=compare_plans(base);save('output_success.json',good)
long=deepcopy(base)
for m in long['tier1']['medications']:m.update(days_supply=60,quantity_per_fill=60)
save('input_partial.json',long);save('output_partial.json',compare_plans(long))
bad=deepcopy(base);bad['tier1']['medications'][0]['strength']='unknown'
save('input_clarification.json',bad);save('output_clarification.json',compare_plans(bad))
# JSON Schema Draft 2020-12. Extra metadata is allowed for compatibility.
def obj(properties,required=None):
    return {'type':'object','properties':properties,'required':required if required is not None else list(properties)}
string={'type':'string'}
identifier={'type':'string','pattern':'^[0-9]+$'}
med=obj({'medication_name':string,'rxcui':identifier,'ndc':{'type':'string','pattern':'^[0-9]{11}$'},'strength':string,'dosage_form':string,'quantity_per_fill':{'type':'number','exclusiveMinimum':0},'days_supply':{'enum':[30,60,90]},'assume_year_round_use':{'const':True}})
pharm=obj({k:string for k in ['location_id','pharmacy_number','npi','location_name','zip_code']})
input_schema=obj({'tier1':obj({'lives_in_michigan':{'const':'Yes'},'extra_help_status':{'const':'No'},'medications':{'type':'array','items':med},'pharmacy_location':pharm}), 'tier2':{'type':'object'},'tier3':{'type':'object'}},['tier1'])
input_schema.update({'$schema':'https://json-schema.org/draft/2020-12/schema','title':'Planwise supported cost input v1'})
save('cost_input.schema.json',input_schema)
# The output schema validates the serialized response, including decimal strings.
money={'type':'string','pattern':'^[0-9]+(?:\\.[0-9]+)?$'}
nullable={'anyOf':[money,{'type':'null'}]}
arr={'type':'array','items':string}
plan=obj({**{k:string for k in ['contract_id','plan_id','segment_id','plan_name']},'premium':money,'deductible':money,'annual_premium':money,'annual_total':nullable,'annual_medication_cost':nullable,'status':{'enum':['estimated_under_documented_assumptions','estimate_unavailable']},'warnings':arr,'unavailable_reasons':arr,'issue_codes':arr})
plan['allOf']=[{'if':{'properties':{'status':{'const':'estimate_unavailable'}}},'then':{'properties':{'annual_total':{'type':'null'},'annual_medication_cost':{'type':'null'},'unavailable_reasons':{'minItems':1}}},'else':{'properties':{'annual_total':money,'annual_medication_cost':money},'required':['medication_inputs','monthly_costs','fill_ledger','deductible_paid','fill_count','peak_monthly_total','average_monthly_total']}}]
# Describe successful nested records from the known serialized interface.
# Optional pre-deductible rule uses the same rule structure or null.
def shape(value):
    if value is None:return {'type':'null'}
    if isinstance(value,bool):return {'type':'boolean'}
    if isinstance(value,int):return {'type':'integer'}
    if isinstance(value,float):return {'type':'number'}
    if isinstance(value,D):return money
    if isinstance(value,str):return {'type':'string'}
    if isinstance(value,list):return {'type':'array','items':shape(value[0]) if value else {}}
    return obj({k:shape(v) for k,v in value.items()})
sample=good['plans'][0]
for field in ['medication_inputs','monthly_costs','fill_ledger','deductible_paid','fill_count','peak_monthly_total','average_monthly_total']:
    plan['properties'][field]=shape(sample[field])
plan['properties']['medication_inputs']['items']['properties']['pre_rule']={'anyOf':[shape(sample['medication_inputs'][0]['rule']),{'type':'null'}]}
plan['properties']['pharmacy_status']={'enum':['preferred','standard']}
output_schema={'$schema':'https://json-schema.org/draft/2020-12/schema','title':'Planwise cost output v1','oneOf':[obj({'status':{'const':'completed'},'plan_year':{'const':2026},'source_release':string,'schedule':string,'validation':string,'assumptions':arr,'preferences':{'type':'object'},'coverage_summary':obj({'plans_considered':{'type':'integer'},'plans_estimated':{'type':'integer'},'plans_unavailable':{'type':'integer'},'complete_comparison':{'type':'boolean'}}),'plans':{'type':'array','items':plan}}),obj({'status':{'const':'invalid_or_unsupported_input'},'errors':{'type':'array','items':string,'minItems':1},'plans':{'type':'array','maxItems':0}})]}
save('cost_output.schema.json',output_schema)
from jsonschema import Draft202012Validator
for schema in (input_schema,output_schema):Draft202012Validator.check_schema(schema)
for name in ('success','partial'):
    Draft202012Validator(input_schema).validate(json.loads((OUT/f'input_{name}.json').read_text()))
for name in ('success','partial','clarification'):
    Draft202012Validator(output_schema).validate(json.loads((OUT/f'output_{name}.json').read_text()))
# Independent source-based arithmetic: no use of engine ledger or payment helpers
# to obtain expected amounts. Choose simple deductible-applicable low-cost cases.
checks=[]
with duckdb.connect(str(ROOT/'data/planwise.duckdb'),read_only=True) as con:
    premium,deductible=con.execute("SELECT premium,deductible FROM clean.plans WHERE contract_id='S4802' AND plan_id='084' AND segment_id='000'").fetchone()
    for label,count,supply,fills in [('one_medication_30_days',1,30,13),('two_medications_shared_deductible',2,30,13),('two_medications_90_days',2,90,5)]:
        p=deepcopy(base);p['tier1']['medications']=p['tier1']['medications'][:count]
        source=[];expected_drugs=D(0)
        for m in p['tier1']['medications']:
            m.update(days_supply=supply,quantity_per_fill=supply)
            rows=con.execute('''SELECT d.unit_cost,n.generic_dispensing_fee_''' + str(supply) + ''',n.floor_price,c.ded_applies_yn
              FROM clean.named_plan_drugs d JOIN clean.pharmacy_network n USING(contract_id,plan_id,segment_id)
              JOIN clean.cost_sharing_days c ON c.contract_id=d.contract_id AND c.plan_id=d.plan_id AND c.segment_id=d.segment_id AND c.tier=d.tier AND c.days_supply_days=d.days_supply AND c.coverage_level=1
              WHERE d.contract_id='S4802' AND d.plan_id='084' AND d.segment_id='000' AND d.ndc=? AND d.rxcui=? AND d.days_supply=? AND n.pharmacy_number=?''',[m['ndc'],m['rxcui'],supply,p['tier1']['pharmacy_location']['pharmacy_number']]).fetchall()
            assert len(rows)==1
            unit,fee,floor,applies=rows[0];assert applies=='Y'
            gross=max(unit*supply+fee,floor).quantize(D('.01'),rounding=ROUND_HALF_UP)
            expected_drugs+=gross*fills
            source.append({'ndc':m['ndc'],'unit_cost':unit,'quantity':supply,'fee':fee,'floor':floor,'price_per_fill':gross,'purchases':fills})
        assert expected_drugs<deductible # all modeled expenses remain below shared deductible
        expected=premium*12+expected_drugs
        actual=next(r for r in compare_plans(p)['plans'] if r['contract_id']=='S4802' and r['plan_id']=='084')
        passed=actual['annual_total']==expected and actual['deductible_paid']==expected_drugs
        checks.append({'case':label,'plan':'S4802/084/000 Wellcare Classic','source_inputs':source,'expected_annual_premium':premium*12,'expected_medication_cost':expected_drugs,'expected_annual_total':expected,'calculated_annual_total':actual['annual_total'],'pass':passed,'reason':'All modeled drug spending is below the single plan deductible; member pays that spending plus annual premiums.'})
# A deliberately hypothetical boundary proves sharing when the deductible runs out.
# $260 gross - $15 shared deductible = $245; 25% is $61.25; plus $15 and $120 premiums = $196.25.
drugs=[{'ndc':x,'medication_name':'Hypothetical '+x,'gross_per_fill':D(10),'deductible_applies':True,'rule':{'type':'2','amount':'.25','minimum':'0','maximum':'0'}} for x in ('A','B')]
actual=simulate({'premium':10,'deductible':15},drugs)
checks.append({'case':'hypothetical_shared_deductible_boundary','expected_annual_total':'196.25','calculated_annual_total':actual['annual_total'],'pass':actual['annual_total']==D('196.25') and actual['deductible_paid']==15,'reason':'13 × 2 × $10 = $260; $15 + 25% × ($260 − $15) + 12 × $10 = $196.25. Synthetic arithmetic fixture, not a CMS plan.'})
assert all(c['pass'] for c in checks)
save('calculation_checks.json',{'method':'Separately derived arithmetic under existing documented assumptions; not external clinical/benefit validation','checks':checks,'external_validation':False})
print(json.dumps(checks,indent=2,default=json_default))
